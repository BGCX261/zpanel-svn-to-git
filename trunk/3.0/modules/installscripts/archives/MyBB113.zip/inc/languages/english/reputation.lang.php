<?php
$l['reputation'] = "Reputation";
$l['error'] = "Error";
$l['error_own_reputation'] = "You cannot add to or remove points from your own reputation.";
$l['error_reputation_same_post'] = "You have already expressed your opinion on this user's post.";
$l['error_max_reputations_day'] = "You have reached the maximum number of reputations you can give to others per day.";
$l['error_reputationdisabled'] = "You are not allowed to add reputation to this user.";
$l['close_window'] = "close window";
$l['add_reputation'] = "Add to {1}'s reputation";
$l['positive'] = "Positive";
$l['negative'] = "Negative";
$l['post_comments'] = "Your comments on this post:";
$l['add_to_reputation'] = "Add to Reputation";
?>