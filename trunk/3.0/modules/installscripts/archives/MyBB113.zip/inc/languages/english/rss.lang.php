<?php
$l['forum'] = "Forum:";
$l['posted_by'] = "Posted By:";
$l['on'] = "on";
?>