<?php

$l['nav_sendthread'] = "Send Thread to Friend";

$l['send_thread'] = "Send To Friend";
$l['recipient'] = "Recipient:";
$l['recipient_note'] = "Enter your friend's email address here.";
$l['subject'] = "Subject:";
$l['message'] = "Message:";
$l['your_name'] = "Your Name:";
$l['name_note'] = "You must provide a name so that the recipient knows who you are.";
$l['your_email'] = "Your Email Address:";
$l['email_note'] = "You must provide a valid email address so the recipient can reply.";

?>