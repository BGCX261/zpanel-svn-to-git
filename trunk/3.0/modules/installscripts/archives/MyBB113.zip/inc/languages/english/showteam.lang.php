<?php

$l['nav_showteam'] = "Forum Team";
$l['forum_team'] = "Forum Team";
$l['moderators'] = "Moderators";
$l['mod_username'] = "Username";
$l['mod_forums'] = "Forum(s)";
$l['mod_email'] = "Email";
$l['mod_pm'] = "PM";
$l['uname'] = "Username";
$l['email'] = "Email";
$l['pm'] = "PM";
?>
