<?php
$db_settings['host'] = "localhost";
$db_settings['user'] = "";
$db_settings['pw'] = "";
$db_settings['db'] = "";
$db_settings['settings_table'] = "forum_settings";
$db_settings['forum_table'] = "forum_entries";
$db_settings['category_table'] = "forum_categories";
$db_settings['userdata_table'] = "forum_userdata";
$db_settings['smilies_table'] = "forum_smilies";
$db_settings['banlists_table'] = "forum_banlists";
$db_settings['useronline_table'] = "forum_useronline";
?>