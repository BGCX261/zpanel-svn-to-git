my little forum
version 1.6.2 - 07/03/2006
Copyright (C) 2005 alex at mylittlehomepage dot net
http://www.mylittlehomepage.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


Installation:

The script requires PHP > 4.1 and a MySQL database.

* The file forum.zip contains a folder with the script files ("forum").
* Load up the complete folder on your server.
* The file db_settings.php requires write permission! Set this with your FTP programm
  (CHMOD 666).
* Start install.php on your server (http://www.domain.tld/forum/install.php).
* Fill in the form completely.
* After installing, remove the file install.php from the server!
* You can now log in with the name and password you specefied at the installation.
  In the "admin area" you can then customize the forum.
* To customize the layout, edit the files template.html and style.css.