<?php
// This file will generate and return the main page of the site
$CONF = array();
$CONF['Self'] = 'index.php';

include('./config.php');

selector();

?>
