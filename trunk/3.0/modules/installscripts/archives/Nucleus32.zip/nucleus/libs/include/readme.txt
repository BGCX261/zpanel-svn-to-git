README for the libs/include directory
-------------------------------------

This directory contains templates used by the admin-area. 
They're not really intended to be edited by the people using Nucleus (i.e. there's 
no documentation and little support). But if you really can't stop yourself,
go ahead :)