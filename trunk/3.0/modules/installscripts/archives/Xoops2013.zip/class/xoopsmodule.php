<?php
// $Id: xoopsmodule.php,v 1.8 2003/03/27 14:56:17 okazu Exp $
if (!defined('XOOPS_ROOT_PATH')) {
	exit();
}
/**
 * this file is for backward compatibility only 
 *
 **/
/**
 * load the new module class 
 **/
require_once XOOPS_ROOT_PATH.'/kernel/module.php';
?>