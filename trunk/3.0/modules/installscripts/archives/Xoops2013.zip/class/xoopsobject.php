<?php
// $Id: xoopsobject.php,v 1.8 2003/03/27 14:56:17 okazu Exp $
if (!defined('XOOPS_ROOT_PATH')) {
	exit();
}
/**
 * this file is for backward compatibility only
 * @package kernel
 **/
/**
 * Load the new object class 
 **/
require_once XOOPS_ROOT_PATH.'/kernel/object.php';
?>