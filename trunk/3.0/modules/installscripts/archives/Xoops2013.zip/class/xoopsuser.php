<?php
// $Id: xoopsuser.php,v 1.8 2003/03/27 14:56:18 okazu Exp $
// this file is for backward compatibility only
if (!defined('XOOPS_ROOT_PATH')) {
	exit();
}
require_once XOOPS_ROOT_PATH.'/kernel/user.php';
?>