<?php
// $Id$
define("XOOPS_VERSION","XOOPS 2.0.13.2");
?>