<?php
// $Id: finish.php,v 1.5 2003/02/12 11:35:36 okazu Exp $
$content .=
"<u><b>Your site</b></u>
<p>Click <a href='../index.php'>HERE</a> to see the home page of your site.</p>
<u><b>Way to use</b></u>
<p>[not yet]</p>
<u><b>Support</b></u>
<p>Visit <a href='http://www.xoops.org/' target='_blank'>XOOPS.org</a></p>
";
?>