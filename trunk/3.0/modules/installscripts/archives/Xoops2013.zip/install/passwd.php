<?php
//  If you use HTTP authentication for XOOPS installer,
//  put user name and passward in the define statement below.
define('INSTALL_USER', '');
define('INSTALL_PASSWD', '');
?>