<?php
define("_MAIL_MSGBODY", "Message body is not set.");
define("_MAIL_FAILOPTPL", "Failed opening template file.");
define("_MAIL_FNAMENG", "From Name is not set.");
define("_MAIL_FEMAILNG", "From Email is not set.");
define("_MAIL_SENDMAILNG", "Could not send mail to %s.");
define("_MAIL_MAILGOOD", "Mail sent to %s.");
define("_MAIL_SENDPMNG", "Could not send private message to %s.");
define("_MAIL_PMGOOD", "Private message sent to %s.");
?>