<?php
// $Id: main.php,v 1.8.20.1 2005/10/28 00:48:31 skalpa Exp $
//%%%%%%		File Name contact.php 		%%%%%
define("_CT_CONTACTFORM","Contact Us Form");
define("_CT_THANKYOU","Thank you for your interest in our site!");
define("_CT_NAME","Name");
define("_CT_EMAIL","Email");
define("_CT_URL","URL");
define("_CT_ICQ","ICQ");
define("_CT_COMPANY","Company");
define("_CT_LOCATION","Location");
define("_CT_COMMENTS","Comments");
define("_CT_SUBMIT","Submit");
define("_CT_YOURMESSAGE","Your Message:");
define("_CT_WEBMASTER","Webmaster");
define("_CT_HELLO","Hello %s,");
define("_CT_THANKYOUCOMMENTS","Thank you for your comments about %s.");
define("_CT_SENTTOWEBMASTER","Your message has been sent to the webmaster(s) of %s.");
define("_CT_SUBMITTED","%s submitted the following Information:");
define("_CT_MESSAGESENT","Message to %s Sent");
define("_CT_SENTASCONFIRM","Your comments have been sent to: %s as a confirmation email.");
define("_CT_INVALIDMAIL", "Invalid e-mail address" );
?>