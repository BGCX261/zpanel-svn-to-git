<?php
// $Id: modinfo.php,v 1.8 2004/12/26 19:11:54 onokazu Exp $
// Module Info

// The name of this module
define("_MI_CONTACT_NAME","Contact Us");
// A brief description of this module
define("_MI_CONTACT_DESC","For sending messages to the webmaster");
?>