<?php
// $Id: blocks.php,v 1.9 2004/12/26 19:11:56 onokazu Exp $
// Blocks
define("_MB_MYDOWNLOADS_DISP","Display");
define("_MB_MYDOWNLOADS_FILES","Files");
define("_MB_MYDOWNLOADS_CHARS","Length of the title");
define("_MB_MYDOWNLOADS_LENGTH"," characters");
?>