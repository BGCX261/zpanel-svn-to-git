<?php
// $Id: blocks.php,v 1.9 2004/12/26 19:11:57 onokazu Exp $
// Blocks
define("_MB_MYLINKS_DISP","Display");
define("_MB_MYLINKS_LINKS","Links");
define("_MB_MYLINKS_CHARS","Length of the title");
define("_MB_MYLINKS_LENGTH"," characters");
?>