<?php
// $Id: blocks.php,v 1.8 2004/12/26 19:12:01 onokazu Exp $
define("_MB_NEWS_NOTYET","There isn't a Biggest Story for Today, yet.");
define("_MB_NEWS_TMRSI","Today's most read Story is:");
define("_MB_NEWS_ORDER","Order");
define("_MB_NEWS_DATE","Published Date");
define("_MB_NEWS_HITS","Number of Hits");
define("_MB_NEWS_DISP","Display");
define("_MB_NEWS_ARTCLS","articles");
define("_MB_NEWS_CHARS","Length of the title");
define("_MB_NEWS_LENGTH"," characters");
?>