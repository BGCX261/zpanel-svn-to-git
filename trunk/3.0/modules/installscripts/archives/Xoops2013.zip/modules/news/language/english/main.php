<?php
// $Id: main.php,v 1.10 2004/12/26 19:12:01 onokazu Exp $
//%%%%%%		File Name index.php 		%%%%%
define("_NW_PRINTER","Printer Friendly Page");
define("_NW_SENDSTORY","Send this Story to a Friend");
define("_NW_READMORE","Read More...");
define("_NW_COMMENTS","Comments?");
define("_NW_ONECOMMENT","1 comment");
define("_NW_BYTESMORE","%s bytes more");
define("_NW_NUMCOMMENTS","%s comments");


//%%%%%%		File Name submit.php		%%%%%
define("_NW_SUBMITNEWS","Submit News");
define("_NW_TITLE","Title");
define("_NW_TOPIC","Topic");
define("_NW_THESCOOP","The Scoop");
define("_NW_NOTIFYPUBLISH","Notify by mail when published");
define("_NW_POST","Post");
define("_NW_GO","Go!");
define("_NW_THANKS","Thanks for your submission."); //submission of news article

define("_NW_NOTIFYSBJCT","NEWS for my site"); // Notification mail subject
define("_NW_NOTIFYMSG","Hey! You got a new submission for your site."); // Notification mail message

//%%%%%%		File Name archive.php		%%%%%
define("_NW_NEWSARCHIVES","News Archives");
define("_NW_ARTICLES","Articles");
define("_NW_VIEWS","Views");
define("_NW_DATE","Date");
define("_NW_ACTIONS","Actions");
define("_NW_PRINTERFRIENDLY","Printer Friendly Page");

define("_NW_THEREAREINTOTAL","There are %s article(s) in total");

// %s is your site name
define("_NW_INTARTICLE","Interesting Article at %s");
define("_NW_INTARTFOUND","Here is an interesting article I have found at %s");

define("_NW_TOPICC","Topic:");
define("_NW_URL","URL:");
define("_NW_NOSTORY","Sorry, the selected story does not exist.");

//%%%%%%	File Name print.php 	%%%%%

define("_NW_URLFORSTORY","The URL for this story is:");

// %s represents your site name
define("_NW_THISCOMESFROM","This article comes from %s");

// Added language definitions for news expiry date
define("_AM_EXPARTS","Expired Articles");
define("_AM_EXPIRED","Expired");
define("_AM_CHANGEEXPDATETIME","Change the date/time of expiration");
define("_AM_SETEXPDATETIME","Set the date/time of expiration");
define("_AM_NOWSETEXPTIME","It is now set at: %s");
?>