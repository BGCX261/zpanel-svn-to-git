<?php
// $Id: main.php,v 1.9 2004/12/26 19:12:02 onokazu Exp $
define("_AM_SECCONF","Sections Configuration");
define("_MD_MUSTREGFIRST","You need to be a registered user or logged in to send a modify request.<br>Please register or login first!");
define("_MD_WELCOMETOSEC","Welcome to the Special Sections at %s");  // %s is your site name
define("_MD_HEREUCANFIND","Here you can find some cool articles that are not presented on the homepage.");
define("_MD_THISISSECTION","This is Section <b>%s</b>");  // %s is a section name
define("_MD_THEFOLLOWING","The following are articles published in this section.");
define("_MD_PRINTERPAGE","Printer Friendly Page");
define("_MD_RETURN2INDEX","Return to Sections Index");
define("_MD_BACK2SEC","Back to %s");
define("_MD_NEXTPAGE","Next Page");
define("_MD_PREVPAGE","Previous Page");
define("_MD_COMESFROM","This article comes from %s");
define("_MD_URLFORTHIS","The URL for this story is:");

define("_MD_CURACTIVESEC","Current Active Sections");
define("_MD_CLICK2EDIT","Click to Edit");
define("_MD_ADDARTICLE","Add Article in Sections");
define("_MD_TITLEC","Title:");
define("_MD_CONTENTC","Content:");
define("_MD_DOADDARTICLE","Add Article!");
define("_MD_LAST20ART","Last 20 Articles");
define("_MD_EDIT","Edit");
define("_MD_EDITARTID","Edit Article ID:");
define("_MD_GO","Go!");
define("_MD_ADDNEWSEC","Add a New Section");
define("_MD_SECNAMEC","Section Name:");
define("_MD_MAXCHAR","(40 characters Max.)");
define("_MD_SECIMAGEC","Section Image:");
define("_MD_EXIMAGE","(example: opinion.gif)");
define("_MD_GOADDSECTION","Add Section!");
define("_MD_EDITARTICLE","Edit Article");
define("_MD_SAVECHANGES","Save Changes");
define("_MD_DELETE","Delete");
define("_MD_EDITTHISSEC","Edit Section: %s"); // %s is a section name
define("_MD_THISSECHAS","This Section has %s articles attached");
define("_MD_RUSUREDELSEC","Are you sure you want to delete section?");
define("_MD_THISDELETESALL","This will delete ALL its articles!");
define("_MD_YES","Yes");
define("_MD_NO","No");
define("_MD_DELETETHISART","Delete Article: %s"); // %s is a section name
define("_MD_RUSUREDELART","Are you sure you want to delete article?");
define("_MD_DBUPDATED","Database Updated Successfully!");
define("_MD_ERRORSECNAME", "You must enter a section name!");
define("_MD_DBNOTUPDATED","Error adding article to the database.<br/>Did you select a section? Please go back and correct the form.");
?>