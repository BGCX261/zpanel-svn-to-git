<?php
// $Id: modinfo.php,v 1.7 2004/12/26 19:12:02 onokazu Exp $
// Module Info

// The name of this module
define("_MI_SECTIONS_NAME","Sections");

// A brief description of this module
define("_MI_SECTIONS_DESC","Creates a section where admins can post various articles.");

// Names of blocks for this module (Not all module has blocks)
//define("_MI_","");

// Names of admin menu items
define("_MI_SECT_ADMENU1","List Sections");
?>