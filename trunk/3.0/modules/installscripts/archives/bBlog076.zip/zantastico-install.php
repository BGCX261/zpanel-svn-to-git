<?php
               function rec_copy($to_path, $from_path) {
                 mkdir($to_path, 0777); 
                 $this_path = getcwd(); 
                 if (is_dir($from_path)) {
				 chdir($from_path);
                     $handle=opendir('.'); 
                     while (($file = readdir($handle))!==false) {
                         if (($file != "zantastico-install.php") && ($file != ".") && ($file != "..")) {
                             if (is_dir($file)) {
//							 if ($row_Installers['silent'] == 0) {
//								 echo ('Changing into folder '.$file.'...<br>');
//							 }
                                 rec_copy ($to_path.'/'.$file."/", $from_path.'/'.$file."/"); 
                                 chdir($from_path);
                             }
                             if (is_file($file)){ 
                                 copy($from_path.'/'.$file, $to_path.'/'.$file); 
//							 	 if ($row_Installers['silent'] == 0) {
//									 echo ('Copyed file '.$file.'...<br>');
//							 	 }
                       		 } 
                         } 
                     } 
                 closedir($handle); 
                 } 
			}
?>

<style type="text/css">
<!--
.content {
	background-color: #FFFFFF;
	border: 1px solid #666666;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
	color: #333333;
	text-decoration: none;
}
</style>
<table width="90%"  border="0" align="center" cellpadding="0" cellspacing="0" class="content">
  <tr align="left" valign="top">
    <td width="51%"><img src="modules/Zantastico/img/logo.gif"><br></td>
    <td width="49%" valign="middle"><div align="center"></div></td>
  </tr>
  <tr align="left" valign="top">
    <td height="222" colspan="2"><div align="center">
      <p>&nbsp;</p>
      <table width="90%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><br>
            <?php
		if (isset($_POST['Install'])) {
			echo 'Deploying...<br><br>';
	
			if (file_exists($row_User['homedir'].'/'.$_POST['scriptpath'])) {
				die ("<font size='2' face='Verdana, Arial, Helvetica, sans-serif' color='red'>Sorry, that directory already exists. You need to choose an install directory that doesn't already exist.<br><a href=javascript:history.back()>Go Back</a></font>");
			}
	
			echo 'Deploying files on to your account...<br>';
	
			$to_path = ($row_User['homedir'].'/'.$_POST['scriptpath']);
			$from_path = $filepath;
			rec_copy($to_path, $from_path);
	
			echo '<br><b>Done!</b> Your installation is almost complete... To finish the install, visit:<br>&nbsp;&nbsp;&nbsp;<a href='.$row_User['url'].'/'.$_POST['scriptpath'].' target=_blank>'.$row_User['url'].'/'.$_POST['scriptpath'].'</a>';
	
		}else{ ?>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $_GET['page']; ?>&script=<?php echo $_GET['script']; ?>" method="post" enctype="application/x-www-form-urlencoded" name="form1">
              <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Your URL: <b><?php echo $row_User['url']; ?></b>
                  <input name="url" type="hidden" id="url" value="<?php echo $row_User['url']; ?>">
                  <br>
    Destination to deploy: <b><?php echo $row_User['url']; ?>/
    <input name="scriptpath" type="text" id="scriptpath" value="<?php echo $_GET['name']; ?>" size="15">
  </b></p>
              <p align="left">After <strong><?php echo $_GET['name']; ?></strong> has been deployed on your account, You will be taken to the Installer. </p>
              <p align="left">Please be sure that you have a MySQL database setup, Incase the installer needs your database settings. If you need to setup a database on your account you can do so by visiting the <a href="?page=mysql" target="_blank">MySQL panel</a>.</p>
              </font><p align="right">
                <input name="Install" type="submit" id="Install" value="Install">
              </p>
            </form>
            <?php } ?></td>
        </tr>
      </table>
      <p><br>
      </p>
    </div>
    <div align="center"></div></td>
  </tr>
</table>
