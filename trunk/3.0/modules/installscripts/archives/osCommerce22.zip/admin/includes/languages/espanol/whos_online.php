<?php
/*
  $Id: whos_online.php,v 1.6 2003/07/06 20:33:02 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Usuarios Conectados');

define('TABLE_HEADING_ONLINE', 'Conectado');
define('TABLE_HEADING_CUSTOMER_ID', 'ID');
define('TABLE_HEADING_FULL_NAME', 'Nombre');
define('TABLE_HEADING_IP_ADDRESS', 'Direccion IP');
define('TABLE_HEADING_ENTRY_TIME', 'Hora Entrada');
define('TABLE_HEADING_LAST_CLICK', 'Ultimo Click');
define('TABLE_HEADING_LAST_PAGE_URL', 'Ultima URL');
define('TABLE_HEADING_ACTION', 'Acci&oacute;n');
define('TABLE_HEADING_SHOPPING_CART', 'Cesta del Usuario');
define('TEXT_SHOPPING_CART_SUBTOTAL', 'Subtotal');
define('TEXT_NUMBER_OF_CUSTOMERS', 'Hay actualmente %s clientes en l�nea');
?>