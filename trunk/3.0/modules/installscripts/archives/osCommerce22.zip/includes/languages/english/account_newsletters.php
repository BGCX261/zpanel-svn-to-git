<?php
/*
  $Id: account_newsletters.php,v 1.1 2003/05/19 19:55:45 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Newsletter Subscriptions');

define('HEADING_TITLE', 'Newsletter Subscriptions');

define('MY_NEWSLETTERS_TITLE', 'My Newsletter Subscriptions');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'General Newsletter');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Including store news, new products, special offers, and other promotional announcements.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Your newsletter subscriptions have been successfully updated.');
?>
