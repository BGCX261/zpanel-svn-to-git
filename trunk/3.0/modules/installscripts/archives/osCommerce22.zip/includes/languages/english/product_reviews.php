<?php
/*
  $Id: product_reviews.php,v 1.6 2003/06/05 23:23:52 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Reviews');

define('TEXT_CLICK_TO_ENLARGE', 'Click to enlarge');

define('TEXT_OF_5_STARS', '%s of 5 Stars!');
?>