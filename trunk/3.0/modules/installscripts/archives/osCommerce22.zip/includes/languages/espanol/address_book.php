<?php
/*
  $Id: address_book.php,v 1.10 2003/07/08 16:45:36 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Mis Direcciones');

define('HEADING_TITLE', 'Mis Direcciones Postales');

define('PRIMARY_ADDRESS_TITLE', 'Direcci&oacute;n Principal');
define('PRIMARY_ADDRESS_DESCRIPTION', 'Esta direcci&oacute;n se seleccionara por defecto para el envio y para la facturaci&oacute;n de sus pedidos.<br><br>Esta direcci&oacute;n tambi&eacute;n se utiliz&aacute; para calcular los impuestos que le corresponden.');

define('ADDRESS_BOOK_TITLE', 'Direcciones');

define('PRIMARY_ADDRESS', '(direcci&oacute;n principal)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>NOTA:</b></font> Se permiten un m&aacute;ximo de %s direcciones.');
?>
