<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Salir');
define('NAVBAR_TITLE', 'Salir');
define('TEXT_MAIN', 'Ha solicitado salir de su cuenta. Ahora es seguro abandonar el ordenador.<br><br>Su carrito de la compra ha sido guardado y el contenido del mismo ser&aacute; restaurado cuando vuelva a entrar en su cuenta.');
?>
