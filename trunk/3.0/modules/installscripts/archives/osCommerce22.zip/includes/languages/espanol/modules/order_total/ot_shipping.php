<?php
/*
  $Id: ot_shipping.php,v 1.5 2003/07/08 16:45:36 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Gastos de Env&iacute;o');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Gastos de Env&iacute;o del Pedido');

  define('FREE_SHIPPING_TITLE', 'Env&iacute;o Gratuito');
  define('FREE_SHIPPING_DESCRIPTION', 'Env&iacute;o gratuito para pedidos sobre %s');
?>
