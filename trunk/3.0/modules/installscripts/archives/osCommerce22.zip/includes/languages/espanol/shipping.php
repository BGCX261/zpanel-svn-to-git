<?php
/*
  $Id: shipping.php,v 1.5 2003/07/08 16:45:36 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Env&iacute;os y Devoluciones');
define('HEADING_TITLE', 'Env&iacute;os y Devoluciones');

define('TEXT_INFORMATION', 'Ponga aqui informaci&oacute;n sobre los Env&iacute;os y Devoluciones');
?>
