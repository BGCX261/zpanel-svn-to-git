<?php
/*
  $Id: specials.php,v 1.5 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Ofertas');
define('HEADING_TITLE', 'Consiguelas mientras estan Calientes!');
?>