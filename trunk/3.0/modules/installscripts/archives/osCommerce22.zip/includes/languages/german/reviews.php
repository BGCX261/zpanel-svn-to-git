<?php
/*
  $Id: reviews.php,v 1.6 2002/04/17 15:57:07 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Meinungen');
define('HEADING_TITLE', 'Was sagen die Anderen?');
define('TEXT_OF_5_STARS', '%s von 5 Sternen!');
?>