<?php
/*
  $Id: footer.php,v 1.3 2003/07/09 01:11:06 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/
?>
<!-- footer //-->
        <table cellpadding="0" cellspacing="0" width="100%" border="0">
          <tr>
            <td width="5%" class="leftColumn" align="left" valign="top"><img src="images/layout/left_bottom_curve.gif"></td>
            <td width="94%" background="images/layout/middle_bottom_background.gif" align="right" valign="bottom">&nbsp;</td>
            <td width="1%" align="right" valign="top" class="rightColumn"><img src="images/layout/bottom_right_curve_y.gif"></td>
          </tr>
        </table></td>
        <td width="1%" background="images/layout/midright.gif"><img src="images/pixel_trans.gif" width="15" height="15" border="0" alt=""></td>
      </tr>
      <tr>
        <td width="1%"><img src="images/layout/botleft.gif" width="15" height="15" border="0" alt=""></td>
        <td width="98%" background="images/layout/botmid.gif"><img src="images/pixel_trans.gif" width="15" height="15" border="0" alt=""></td>
        <td width="1%"><img src="images/layout/botright.gif" width="15" height="15" border="0" alt=""></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" class="smallText">Copyright &copy; 2003 <a href="http://www.oscommerce.com">osCommerce</a></td>
  </tr>
</table>
<!-- footer_eof //-->
