<?php
/*
  $Id: header.php,v 1.2 2003/07/09 01:11:06 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/
?>
<!-- header //-->

<p>&nbsp;</p>

<table width="75%" cellpadding="0" cellspacing="0" border="0" align="center">
  <tr>
    <td><table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td width="1%"><img src="images/layout/topleft.gif" width="15" height="15" border="0"></td>
        <td width="98%" background="images/layout/topmid.gif"><img src="images/pixel_trans.gif" width="15" height="15" border="0"></td>
        <td width="1%"><img src="images/layout/topright.gif" width="15" height="15" border="0"></td>
      </tr>
      <tr>
        <td width="1%" background="images/layout/midleft.gif"><img src="images/pixel_trans.gif" width="15" height="15" border="0"></td>
        <td width="98%" bgcolor="ffffff"><table border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
          <tr>
            <td><img src="images/layout/left_header_curve.gif"></td>
            <td width="100%" background="images/layout/middle_header_filler.gif">&nbsp;</td>
            <td align="right" valign="top"><img src="images/oscommerce.gif" border="0" alt="osCommerce"></td>
          </tr>
        </table>
<!-- header_eof //-->
