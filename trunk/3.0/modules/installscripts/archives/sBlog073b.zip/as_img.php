<?php

	$key = (array_key_exists('k', $_GET) && strlen($_GET['k']) == 4) ? $_GET['k'] : strtoupper(substr(md5(rand()), 0, 4));

	$im = imagecreatetruecolor(34, 16);

	$bg = imagecolorallocate($im, 0, 0, 0);
	$col_text = imagecolorallocate($im, 255, 255, 255);
	
	imagestring($im, 2, 5, 1, $key, $col_text);

	header('Content-type: image/png');	
	imagepng($im);
	imagedestroy($im);

?>