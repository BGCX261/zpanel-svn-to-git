<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('inc/lang.php');
	require('inc/mysql.php');

	$category		= mysql_real_escape_string($_POST['category']);
	$ref				= sStripSlashes($_POST['ref']);
	$id				= intval($_POST['id']);
	$category_id	= intval($_POST['category_id']);
	$topic			= sStripSlashes($_POST['topic']);
	$text				= sStripSlashes($_POST['text']);
	$date_created	= $_POST['date_created'];

	if($category != '' && $category != '') {
		if(array_key_exists('cat_id', $_POST) && intval($_POST['cat_id']) > 0) {
			$cat_id = intval($_POST['cat_id']);
			$query = 'UPDATE ' . $conf_mysql_prefix . 'categories SET category=\'' . $category. '\' WHERE id=\'' . $cat_id . '\' LIMIT 1';
			$msg[] = lang('The category has been updated.');
		}
		else {
			$query = 'INSERT INTO ' . $conf_mysql_prefix . 'categories SET date_created=NOW(), category=\'' . $category. '\'';
			$msg[] = lang('The category has been created.');
		}
		
		mysql_query($query);
	}
	else {
		$msg[] = lang('Could not create category!');
	}
	
	mysql_close();
	
	// include headers
	require('inc/tpl_header.php');		// header
	require('inc/tpl_menu.php');			// menu

	// include blocks
	require('inc/block_custom.php');			// custom blocks
	
	ob_start();

?>
		<div class="sblog_post">
		<div class="sblog_post_topic">
			<h1><?php echo lang('Categories'); ?></h1>
		</div>
		<div class="sblog_post_text">
			<form id="temp" method="post" action="<?php echo $ref; ?>">
			<div>
				<input type="submit" value="<?php echo lang('Go back'); ?>" class="sblog_button" />
			</div><br />
			<fieldset>
				<input type="hidden" name="ref" id="ref" value="<?php echo $ref; ?>" />
				<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
				<input type="hidden" name="category_id" id="category_id" value="<?php echo $category_id; ?>" />
				<input type="hidden" name="topic" id="topic" value="<?php echo htmlspecialchars($topic); ?>" />
				<input type="hidden" name="text" id="text" value="<?php echo htmlspecialchars($text); ?>" />
				<input type="hidden" name="date_created" id="date_created" value="<?php echo $date_created; ?>" />
				<legend><?php echo lang('Message(s)'); ?></legend>
<?php

	if(isset($msg)) {
		foreach($msg as $message) {
			echo $message . '<br />' . "\n";
		}
	}

?>
			</fieldset>
			</form>
		</div>
		<div class="sblog_post_options">&nbsp;</div>
		</div>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);

	ob_end_clean();
	
	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>