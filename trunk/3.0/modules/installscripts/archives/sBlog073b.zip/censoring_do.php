<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// import some important stuff
	require('inc/config.php');
	require('inc/mysql.php');

	// define variables
	$word_orig = mysql_real_escape_string($_POST['word_orig']);
	$word_repl = mysql_real_escape_string($_POST['word_repl']);
	
	// prevent blank posting
	if($word_orig != '' && $word_repl != '') {

		if(array_key_exists('id', $_POST) && intval($_POST['id']) > 0) {		
			$id = intval($_POST['id']);
			$query = 'UPDATE ' . $conf_mysql_prefix . 'censoring SET word_orig=\'' . $word_orig . '\', word_repl=\'' . $word_repl . '\' WHERE id=\'' . $id . '\' LIMIT 1';
		}
		else {
			$query = 'INSERT INTO ' . $conf_mysql_prefix . 'censoring SET word_orig=\'' . $word_orig . '\', word_repl=\'' . $word_repl . '\'';
		}

		mysql_query($query);
	}
	
	mysql_close();

	header('Location: censoring.php');
	exit;

?>