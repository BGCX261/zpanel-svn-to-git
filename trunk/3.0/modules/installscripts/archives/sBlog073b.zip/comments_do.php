<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// import some important stuff
	require('inc/config.php');
	require('inc/mysql.php');

	// define variables
	$blog_id = (array_key_exists('blog_id', $_POST) && intval($_POST['blog_id']) > 0) ? intval($_POST['blog_id']) : null;
	$username = (array_key_exists('username', $_POST) && strlen($_POST['username']) > 0) ? mysql_real_escape_string($_POST['username']) : null;
	$email = (array_key_exists('email', $_POST) && strlen($_POST['email']) > 0) ? mysql_real_escape_string($_POST['email']) : null;
	$homepage = (array_key_exists('homepage', $_POST) && strlen($_POST['homepage']) > 0) ? mysql_real_escape_string(str_replace('http://', '', $_POST['homepage'])) : null;
	$comment = (array_key_exists('comment', $_POST) && strlen($_POST['comment']) > 0) ? mysql_real_escape_string($_POST['comment']) : null;
	$h = (array_key_exists('h', $_POST) && strlen($_POST['h']) == 4) ? strtoupper($_POST['h']) : null;
	$k = (array_key_exists('k', $_POST) && strlen($_POST['k']) == 4) ? strtoupper($_POST['k']) : null;

	// add comment	
	if(strlen($username) > 0 && strlen($comment) > 0 && $k != null && $k == $h) {
		$queryChk = 'SELECT id FROM ' . $conf_mysql_prefix . 'data WHERE id=\'' . $blog_id . '\'';
		$qChk = mysql_query($queryChk);
		$nChk = mysql_num_rows($qChk);

		if($nChk > 0) {
			$query = 'INSERT INTO ' . $conf_mysql_prefix . 'comments SET blog_id=\'' . $blog_id . '\', date_created=NOW(), username=\'' . $username . '\', email=\'' . $email . '\', homepage=\'' . $homepage . '\', comment=\'' . $comment . '\'';
			$expire = time() + (3600 * 24 * 365);
			
			setcookie('comment_username', $username, $expire);
			setcookie('comment_email', $email, $expire);
			setcookie('comment_homepage', $homepage, $expire);
	
			mysql_query($query);
			
			$id = mysql_insert_id();
		}
		else {
			$id = null;
		}
	}
	else {
		$id = null;
	}
	
	// send mail to admin
	if(strlen($username) > 0 && strlen($comment) > 0 && isset($conf_comments_email) && $conf_comments_email == 1 && $k != null && $k == $h) {
		
		// include function for stripping out bbcodes
		require('inc/func_truncate.php');
		require('inc/func_bbcode_strip.php');
		
		// import mail template
		$tpl = implode('', file($conf_doc_root . 'template/mail/comment.tpl'));
		
		// define url var
		$url = sRewrite('article', 'id', $blog_id, 'anchor', $id);
		
		$pattern	=	array(
							'<name>',
							'<email>',
							'<comment>',
							'<url>'
						);
		
		$replace	=	array(
							$username,
							$email,
							str_replace('<br />', '', bbcode_strip($_POST['comment'])),
							$url
						);
		
		// define mail vars
		$to		= $conf_admin_email;
		$subject	= $conf_page_title . ': New comment';
		$body		= str_replace($pattern, $replace, $tpl);
		$from		= 'From: sblog-mailer@' . $_SERVER['HTTP_HOST'] . "\r\n";

		// send mail to admin
		mail($to, $subject, $body, $from);
	}
	
	mysql_close();
	header('Location: ' . sRewrite('article', 'id', $blog_id, 'anchor', $id));
	exit;

?>