<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// admin only
	require('inc/auth.php');

	// some important stuff
	require('inc/config.php');
	require('inc/sPing.php');
	require('inc/func_truncate.php');
	require('inc/func_bbcode_strip.php');

	// update post
	if(array_key_exists('id', $_POST) && intval($_POST['id']) > 0) {
		require('inc/mysql.php');

		$id				= intval($_POST['id']);
		$topic			= mysql_real_escape_string(sStripSlashes($_POST['topic']));
		$text				= mysql_real_escape_string(sStripSlashes($_POST['text']));
		$category_id	= intval($_POST['category_id']);

		if(array_key_exists('silent', $_POST) && intval($_POST['silent']) == 1 && array_key_exists('date_created', $_POST) && strlen($_POST['date_created']) == 14) {
			$date_created = $_POST['date_created'];
		}
		else {
			$date_created = gmdate('YmdHis');
		}
		
		if(array_key_exists('ping', $_POST) && intval($_POST['ping']) > 0) {
			$ping = intval($_POST['ping']);
		}
		else {
			$ping = null;
		}
		
		if(array_key_exists('draft', $_POST) && intval($_POST['draft']) > 0) {
			$draft = 1;
		}
		else {
			$draft = 0;
		}
		
		$ping_url = sStripSlashes($_POST['ping_url']);
		
		$query = 'UPDATE ' . $conf_mysql_prefix . 'data SET date_modified=\'' . $date_created . '\', topic=\'' . $topic . '\', text=\'' . $text . '\', category_id=\'' . $category_id . '\', ping=\'' . $ping . '\', ping_url=\'' . $ping_url . '\', draft=\'' . $draft . '\' WHERE id=\'' . $id . '\' LIMIT 1';

		mysql_query($query);
		mysql_close();
		
		// send trackback pings
		if($ping == 1) {
			$hosts = explode("\n", $ping_url);
			
			$excerpt = substr(bbcode_strip($text), 0, 252) . '...';
			
			foreach($hosts as $host) {
				sPing(trim($host), $topic, sRewrite('article', 'id', $id), $excerpt, $conf_page_title);
			}
		}
	}
	// insert post
	else {
		require('inc/mysql.php');

		$topic			= mysql_real_escape_string(sStripSlashes($_POST['topic']));
		$text				= mysql_real_escape_string(sStripSlashes($_POST['text']));
		$category_id	= intval($_POST['category_id']);
		
		if(array_key_exists('ping', $_POST) && intval($_POST['ping']) > 0) {
			$ping = intval($_POST['ping']);
		}
		else {
			$ping = null;
		}
		
		if(array_key_exists('draft', $_POST) && intval($_POST['draft']) > 0) {
			$draft = 1;
		}
		else {
			$draft = 0;
		}
		
		$ping_url = sStripSlashes($_POST['ping_url']);
		
		$query = 'INSERT INTO ' . $conf_mysql_prefix . 'data SET date_created=NOW(), topic=\'' . $topic . '\', text=\'' . $text . '\', category_id=\'' . $category_id . '\', ping=\'' . $ping . '\', ping_url=\'' . $ping_url . '\', draft=\'' . $draft . '\'';
		
		mysql_query($query);
		
		$id = mysql_insert_id();

		mysql_close();
		
		// send trackback pings
		if($ping == 1) {
			$hosts = explode("\n", $ping_url);
			
			$excerpt = substr(bbcode_strip($text), 0, 252) . '...';
			
			foreach($hosts as $host) {
				sPing(trim($host), $topic, sRewrite('article', 'id', $id), $excerpt, $conf_page_title);
			}
		}
	}

	if($draft == 1) {
		header('Location: posts.php');
		exit;
	}
	else {
		header('Location: ' . sRewrite('article', 'id', $id));
		exit;
	}

?>