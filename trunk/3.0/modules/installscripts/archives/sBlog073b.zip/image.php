<?php
	
	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');

	// include blocks
	require('inc/block_custom.php');			// custom blocks
	
	require('inc/mysql.php');
	
	if(array_key_exists('dir_id', $_REQUEST) && intval($_REQUEST['dir_id']) > 0) {
		$dir_id = intval($_REQUEST['dir_id']);
	}
	else {
		$dir_id = 1;
	}
	
	/* start <sblog_main> */
	ob_start();

?>
<div class="sblog_post">
<div class="sblog_post_topic">
	<h1><?php echo lang('Images'); ?></h1>
</div>
<div class="sblog_post_text">
				<form id="image" method="post" action="image_ul.php">
					<div>
						<input type="hidden" name="ref" id="ref" value="<?php echo $_SERVER['PHP_SELF']; ?>" />
						<input type="button" value="<?php echo lang('Scan'); ?>" onclick="javascript:location.href='img_scan.php'" class="sblog_button" />
						<input type="button" value="<?php echo lang('Prune'); ?>" onclick="javascript:location.href='img_prune.php'" class="sblog_button" />
						<input type="submit" value="<?php echo lang('Upload'); ?>" class="sblog_button" /><br /><br />
					</div>
				</form>
				<form id="image_dir" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<fieldset>
						<legend><?php echo lang('Folder'); ?></legend>
						<div>
								<select name="dir_id" id="dir_id" onchange="javascript:submit();">
									<option value="1"><?php echo lang('Default'); ?></option>
<?php

	$queryDir = 'SELECT id, dir_name FROM ' . $conf_mysql_prefix . 'img_dir WHERE id!=\'1\' ORDER BY dir_name ASC';
	$qDir = mysql_query($queryDir);
	
	while($rDir = mysql_fetch_assoc($qDir)) {
		if(array_key_exists('dir_id', $_REQUEST) && intval($_REQUEST['dir_id']) == $rDir['id']) {
			$selected = ' selected="selected"';
		}
		else {
			$selected = null;
		}
		
		echo "\t\t\t\t\t\t\t\t\t" . '<option value="' . $rDir['id'] . '"' . $selected . '>' . htmlspecialchars($rDir['dir_name']) . '</option>' . "\n";
	}

?>
								</select>
								
								<input type="button" value="<?php echo lang('Folders'); ?>" onclick="javascript:location.href='img_folder.php'" class="sblog_button" />
						</div>
					</fieldset>
				</form>
<?php

	require('inc/sImageResize.php');
	
	$queryImg = 'SELECT id, dir_id, filename, filetype, filesize, filemtime, description FROM ' . $conf_mysql_prefix . 'img WHERE dir_id=\'' . $dir_id . '\' ORDER BY filename ASC';
	
	$qImg = mysql_query($queryImg);
	$nImg = mysql_num_rows($qImg);
	
	$counter = 0;

	$pages = ceil($nImg / 10);

	if($nImg > 0) {
		// set active page
		if(array_key_exists('p', $_GET)) {
			$page = intval($_GET['p']);
		}
		else {
			$page = 1;
		}
	
		// jump to active page in database
		mysql_data_seek($qImg, (($page - 1) * 10));

		echo "\t\t\t\t\t" . '<form id="img_list" action="' . $_SERVER['PHP_SELF'] . '">' . "\n";
		echo "\t\t\t\t\t" . '<fieldset>' . "\n";
		echo "\t\t\t\t\t\t" . '<legend>' . lang('Existing images') . '</legend>' . "\n";
		while($rImg = mysql_fetch_assoc($qImg)) {
			$counter++;
			if($counter > 10) {
				break;
			}
			
			if(extension_loaded('gd')) {
				if(!file_exists('upload/tn/' . $rImg['filename'])) {
					@sImageResize('upload/' . $rImg['filename'], 'upload/tn/' . $rImg['filename'], 50, 50);
				}
			}
			
			echo "\t\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
			echo "\t\t\t\t\t\t\t" . '<a href="image_del.php?id=' . $rImg['id'] . '">' . lang('Delete') . '</a>' . "\n";
			echo "\t\t\t\t\t\t\t" . '<a href="image_edit.php?id=' . $rImg['id'] . '">' . lang('Edit') . '</a>' . "\n";
			echo "\t\t\t\t\t\t" . '</div>' . "\n";
			echo "\t\t\t\t\t\t" . '<div class="sblog_val">' . "\n";
			
			if(file_exists('upload/' . $rImg['filename'])) {
				$imgsize = getimagesize('upload/' . $rImg['filename']);
				echo "\t\t\t\t\t\t\t" . '<a href="#" onclick="javascript:window.open(\'image_view.php?filename=' . rawurlencode($rImg['filename']) . '\',\'image\',\'width=' . $imgsize[0] . ',height=' . $imgsize[1] . '\');return false"><img src="upload/tn/' . $rImg['filename'] . '" alt="' . $rImg['filename'] . '" style="padding-right: 5px; vertical-align: top; float: left;" /></a>' . "\n";
				echo "\t\t\t\t\t\t\t" . lang('Filename') . ': <a href="#" onclick="javascript:window.open(\'image_view.php?filename=' . rawurlencode($rImg['filename']) . '\',\'image\',\'width=' . $imgsize[0] . ',height=' . $imgsize[1] . '\');return false">' . $rImg['filename'] . '</a><br />' . "\n";
				echo "\t\t\t\t\t\t\t" . lang('Uploaded') . ': ' . $rImg['filemtime'] . '<br />' . "\n";
				echo "\t\t\t\t\t\t\t" . lang('Dimensions') . ': ' . $imgsize[0] . ' x ' . $imgsize[1] . ' px<br style="clear: both;" />' . "\n";
			}
			else {
				echo "\t\t\t\t\t\t\t" . '<strong style="color: #F00;">' . sprintf(lang('File "%s" does not exist!'), $rImg['filename']) . '</strong><br />' . "\n";
			}
			
			echo "\t\t\t\t\t\t" . '</div>' . "\n";
		}
		echo "\t\t\t\t\t" . '</fieldset>' . "\n";
		echo "\t\t\t\t\t" . '</form>' . "\n";
	}
	
	mysql_close();

?>
			</div>
			<div class="sblog_post_options">&nbsp;</div>
			</div>

<?php

	if($pages > 1) {
		echo "\t\t\t" . '<!-- START OF PAGES -->' . "\n";
		echo "\t\t\t" . '<div class="sblog_pages">' . "\n";
		echo "\t\t\t\t" . '<div class="sblog_pages_prev">' . "\n";
		
		if($page > 1) {
			echo "\t\t\t\t\t" . '<a href="' . $_SERVER['PHP_SELF'] . '?dir_id=' . $dir_id . '&amp;p=1" title="' . lang('First') . '">&laquo; ' . lang('First') . '</a> <a href="' . $_SERVER['PHP_SELF'] . '?dir_id=' . $dir_id . '&amp;p=' . ($page - 1) . '" title="' . lang('Previous') . '">&laquo; ' . lang('Previous') . '</a>' . "\n";
		}
		else {
			echo "\t\t\t\t\t" . '&laquo; ' . lang('First') . ' &laquo; ' . lang('Previous') . "\n";
		}
		
		echo "\t\t\t\t" . '</div>' . "\n";
		echo "\t\t\t\t" . '<div class="sblog_pages_next">' . "\n";
		
		if($page < $pages) {
			echo "\t\t\t\t\t" . '<a href="' . $_SERVER['PHP_SELF'] . '?dir_id=' . $dir_id . '&amp;p=' . ($page + 1) . '" title="' . lang('Next') . '">' . lang('Next') . ' &raquo;</a> <a href="' . $_SERVER['PHP_SELF'] . '?dir_id=' . $dir_id . '&amp;p=' . $pages . '" title="' . lang('Last') . '">' . lang('Last') . ' &raquo;</a>' . "\n";
		}
		else {
			echo "\t\t\t\t\t" . lang('Next') . ' &raquo; ' . lang('Last') . ' &raquo;' . "\n";
		}
		
		echo "\t\t\t\t" . '</div>' . "\n";
		echo "\t\t\t\t" . '<div class="sblog_pages_current">' . "\n";
		echo "\t\t\t\t\t" . $page . ' ' . lang('of') . ' ' . $pages . "\n";
		echo "\t\t\t\t" . '</div>' . "\n";
		echo "\t\t\t" . '</div>' . "\n";
		echo "\t\t\t" . '<!-- END OF PAGES -->' . "\n";
	}

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */
	
	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>