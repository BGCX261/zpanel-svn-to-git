<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// admin only
	require('inc/auth.php');

	if(array_key_exists('id', $_REQUEST) && intval($_REQUEST['id']) > 0) {	
		$id = intval($_REQUEST['id']);
	}
	else {
		$id = null;
	}
	
	// include headers
	require('inc/tpl_header.php');		// header
	require('inc/tpl_menu.php');			// menu
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks
	
	// mysql
	require('inc/mysql.php');
	
	$query = 'SELECT id, dir_id, filename, filesize, UNIX_TIMESTAMP(filemtime) AS filemtime, description FROM ' . $conf_mysql_prefix . 'img WHERE id=\'' . $id . '\' LIMIT 1';
	$q = mysql_query($query);
	$r = mysql_fetch_assoc($q);
	
	$from = intval($r['dir_id']);

	ob_start();
	
?>
	<div class="sblog_post">
		<div class="sblog_post_topic">
			<h1><?php echo lang('Edit'); ?></h1>
		</div>
		<div class="sblog_post_text">
			<form id="move" method="post" action="image_move.php">
				<div>
					<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
					<input type="hidden" name="from" id="from" value="<?php echo $from; ?>" />
					<input type="button" value="<?php echo lang('Cancel'); ?>" onclick="javascript:history.back(-1)" class="sblog_button" />
					<input type="button" value="<?php echo lang('Rename'); ?>" onclick="javascript:location.href='image_rename.php'" class="sblog_button" />
					<input type="button" value="<?php echo lang('Delete'); ?>" onclick="javascript:location.href='image_del.php?id=<?php echo $id; ?>'" class="sblog_button" /><br /><br />
<?php				

	if(file_exists('upload/' . $r['filename'])) {
		$imgsize = getimagesize('upload/' . $r['filename']);
		if($imgsize[0] > $conf_img_width) {
			$width = $conf_img_width;
		}
		else {
			$width = $imgsize[0];
		}
		
		echo "\t\t\t\t" . '<img src="upload/' . $r['filename'] . '" width="' . $width . '" alt="' . htmlspecialchars($r['filename']) . '" /><br />' . "\n";
		echo "\t\t\t\t" . lang('Filename') . ': <strong>' . $r['filename'] . '</strong><br />' . "\n";
		echo "\t\t\t\t" . lang('Filesize') . ': <strong>' . ceil($r['filesize'] / 1024) . ' KB</strong><br />' . "\n";
		echo "\t\t\t\t" . lang('Uploaded') . ': <strong>' . sDateTime($r['filemtime'], '%Y-%m-%d %H:%M') . '</strong><br /><br />' . "\n";

		$queryPosts = 'SELECT id, topic FROM ' . $conf_mysql_prefix . 'data WHERE text LIKE \'%upload/' . $r['filename'] . '%\'';		
		$qPosts = mysql_query($queryPosts);
		$nPosts = mysql_num_rows($qPosts);

		if($nPosts > 0) {
			echo "\t\t\t\t" . lang('This image is used in the following post(s)') . ':' . "\n";
			echo "\t\t\t\t" . '<ul>' . "\n";
			while($rPosts = mysql_fetch_assoc($qPosts)) {
			echo "\t\t\t\t\t" . '<li><a href="' . sRewrite('article', 'id', $rPosts['id']) . '" rel="external" class="sblog_external" title="' . htmlspecialchars($rPosts['topic']) . '">' . $rPosts['topic'] . '</a></li>' . "\n";
			}
			echo "\t\t\t\t" . '</ul>' . "\n";
		}
	}

?>
				</div>
				<fieldset>
					<legend><?php echo lang('Move to folder'); ?></legend>
					<div>
						<select name="to" id="to">
							<option value="1"><?php echo lang('Default'); ?></option>
<?php

	$queryDir = 'SELECT id, dir_name FROM ' . $conf_mysql_prefix . 'img_dir WHERE id!=\'1\' ORDER BY dir_name ASC';
	$qDir = mysql_query($queryDir);
	
	while($rDir = mysql_fetch_assoc($qDir)) {
		if($rDir['id'] == $from) {
			$selected = ' selected="selected"';
		}
		else {
			$selected = null;
		}
		
		echo "\t\t\t\t\t\t\t\t\t" . '<option value="' . $rDir['id'] . '"' . $selected . '>' . htmlspecialchars($rDir['dir_name']) . '</option>' . "\n";
	}

?>
						</select>
						<input type="submit" value="<?php echo lang('Move here'); ?>" class="sblog_button" />
					</div>
				</fieldset>
			</form>
		</div>
		<div class="sblog_post_options">&nbsp;</div>
	</div>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);

	ob_end_clean();
	
	require('inc/tpl_foot.php');
	
	mysql_close();
	
	echo $tpl_main;

?>