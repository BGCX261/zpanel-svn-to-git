<?php

	require('inc/auth.php');

	if(array_key_exists('id', $_POST) && intval($_POST['id']) > 0 && array_key_exists('from', $_POST) && intval($_POST['from']) > 0 && array_key_exists('to', $_POST) && intval($_POST['to']) > 0) {	
		$id = intval($_POST['id']);
		$from = intval($_POST['from']);
		$to = intval($_POST['to']);
	
		$query = 'UPDATE ' . $conf_mysql_prefix . 'img SET dir_id=\'' . $to . '\' WHERE id=\'' . $id . '\' AND dir_id=\'' . $from . '\' LIMIT 1';

		require('inc/mysql.php');		
		mysql_query($query);
		mysql_close();

		header('Location: image_edit.php?id=' . $id);
		exit;
	}
	else {
		header('Location: image.php');
		exit;
	}
	
?>