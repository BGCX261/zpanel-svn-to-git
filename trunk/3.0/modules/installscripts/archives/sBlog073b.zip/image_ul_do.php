<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('inc/config.php');
	require('inc/lang.php');

	require('inc/sImageResize.php');

	// define variables
	if(array_key_exists('id', $_POST)) {
		$id = intval($_POST['id']);
	}
	else {
		$id = null;
	}
	
	if(array_key_exists('ref', $_POST)) {
		$ref = sStripSlashes($_POST['ref']);
	}
	else {
		$ref = null;
	}
	
	if(array_key_exists('topic', $_POST)) {
		$topic = sStripSlashes($_POST['topic']);
	}
	else {
		$topic = null;
	}
	
	if(array_key_exists('text', $_POST)) {
		$text = sStripSlashes($_POST['text']);
	}
	else {
		$text = null;
	}
	
	if(array_key_exists('category_id', $_POST)) {
		$category_id = intval($_POST['category_id']);
	}
	else {
		$category_id = null;
	}
	
	if(array_key_exists('date_created', $_POST)) {
		$date_created = $_POST['date_created'];
	}
	else {
		$date_created = null;
	}
	
	if(array_key_exists('noresize', $_POST) && intval($_POST['noresize']) > 0) {
		$noresize = 1;
	}
	else {
		$noresize = 0;
	}
	
	if(array_key_exists('dir', $_POST)) {
		$dir = intval($_POST['dir']);
	}
	else {
		$dir = 1;
	}

	// check for errors and mime type
	if(array_key_exists('image', $_FILES) && $_FILES['image']['error'] == 0 && substr($_FILES['image']['type'], 0, 5) == 'image') {
		$file_src = $_FILES['image']['tmp_name'];
		$file_dst = 'upload/' . $_FILES['image']['name'];

		if($noresize == 1) {
			move_uploaded_file($file_src, $file_dst);
		}
		else {
			sImageResize($file_src, $file_dst, $conf_img_width, 100);
		}
		
		$filemtime = gmdate('Y-m-d H:i:s', filemtime($file_dst));
		$filesize = filesize($file_dst);

		// add image to image database		
		require('inc/mysql.php');
		$query = 'INSERT INTO ' . $conf_mysql_prefix . 'img SET filename=\'' . $_FILES['image']['name'] . '\', filesize=\'' . $filesize . '\', filemtime=\'' . $filemtime . '\', dir_id=\'' . $dir . '\'';
		mysql_query($query);
		mysql_close();

		$msg[] = lang('Your image was successfully uploaded.');
		$msg[] = lang('You can now access it from the image list.');
	}
	else {
		$error[] = lang('Error');
	}

	// include headers
	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');			// menu

	// include blocks
	require('inc/block_custom.php');			// custom blocks

	ob_start();
	
?>
	<form id="image" method="post" action="<?php echo $ref; ?>">
	<div class="sblog_post">
				<div class="sblog_post_topic">
					<h1><?php echo lang('Images'); ?></h1>
				</div>
				<div class="sblog_post_text">
					<input type="submit" value="<?php echo lang('Go back'); ?>" class="sblog_button" /><br /><br />
<?php

	if(isset($msg)) {
		while(list(, $val) = each($msg)) {
			echo "\t\t" . '<span style="color: #090;">' . $val . '</span>' . "<br />\n";
		}
	}

	if(isset($error)) {
		while(list(, $val) = each($error)) {
			echo "\t\t" . '<span style="color: #C00;">' . $val . '</span>' . "<br />\n";
		}
	}

?>
						<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
						<input type="hidden" name="topic" id="topic" value="<?php echo htmlspecialchars($topic); ?>" />
						<input type="hidden" name="text" id="text" value="<?php echo htmlspecialchars($text); ?>" />
						<input type="hidden" name="category_id" id="category_id" value="<?php echo $category_id; ?>" />
						<input type="hidden" name="date_created" id="date_created" value="<?php echo $date_created; ?>" />
				</div>
				<div class="sblog_post_options">&nbsp;</div>
			</div>
			</form>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();

	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>