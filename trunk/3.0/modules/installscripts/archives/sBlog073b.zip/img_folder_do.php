<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	/* admin only */
	require('inc/auth.php');
	
	/* open mysql onnection */
	require('inc/mysql.php');

	/* define variables */
	$dir_name = mysql_real_escape_string($_POST['dir_name']);
	
	if(array_key_exists('id', $_POST) && intval($_POST['id']) > 1) {
		$id = intval($_POST['id']);
	}
	else {
		$id = null;
	}
	
	if(strlen($dir_name) > 0) {
		if(isset($id)) {
			/* edit folder */
			$query = 'UPDATE ' . $conf_mysql_prefix . 'img_dir SET dir_name=\'' . $dir_name . '\' WHERE id=\'' . $id . '\' LIMIT 1';
			mysql_query($query);
		}
		else {
			/* create new folder */
			$query = 'INSERT INTO ' . $conf_mysql_prefix . 'img_dir SET dir_name=\'' . $dir_name . '\'';
			mysql_query($query);
		}
	}

	/* close mysql connection */	
	mysql_close();
	header('Location: img_folder.php');
	exit;

?>