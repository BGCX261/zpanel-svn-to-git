<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// include headers
	require('inc/tpl_header.php');			// header
	require('inc/tpl_menu.php');				// menu
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks

	/* start <sblog_main> */
	ob_start();

?>
<!-- START OF LIST -->
<div class="sblog_post">
	<div class="sblog_post_topic">
		<h1><?php echo lang('Images') . ': ' . lang('Prune'); ?></h1>
	</div>
	<div class="sblog_post_text">
		<input type="button" value="<?php echo lang('Cancel'); ?>" onclick="javascript:location.href='image.php'" class="sblog_button" />
		<input type="button" value="<?php echo lang('Prune'); ?>" onclick="javascript:location.href='img_prune_do.php'" class="sblog_button" /><br /><br />
		<strong style="color: #F00;"><?php echo lang('This action will delete unused images!'); ?></strong><br /><br />
		<?php echo lang('Are you sure you want to continue?'); ?>
	</div>
	<div class="sblog_post_options">&nbsp;</div>
</div>
<!-- END OF LIST -->
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */
	
	require('inc/tpl_foot.php');

	echo $tpl_main;

?>