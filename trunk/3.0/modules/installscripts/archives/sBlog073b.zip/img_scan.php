<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/config.php');
	require('inc/lang.php');

	// include headers
	require('inc/tpl_header.php');			// header
	require('inc/tpl_menu.php');				// menu
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks
	
	require('inc/mysql.php');

	ob_start();
?>
	<div class="sblog_post">
		<div class="sblog_post_topic">
			<h1><?php echo lang('Images') . ': ' . lang('Scan'); ?></h1>
		</div>
		<div class="sblog_post_text">
			<input type="button" value="<?php echo lang('Go back'); ?>" onclick="javascript:history.go(-1)" class="sblog_button" /><br /><br />
<?php

	$counter = 0;
	
	if($handle = opendir('upload')) {
		while(false !== ($file = readdir($handle))) {
			if(substr($file, -4) == '.jpg' || substr($file, -4) == '.jpe' || substr($file, -5) == '.jpeg' || substr($file, -4) == '.gif' || substr($file, -4) == '.png') {
				$tmp = getimagesize('upload/' . $file);
				$filename = $file;
				$filetype = $tmp['mime'];
				$filesize = filesize('upload/' . $file);
				$filemtime = gmdate('Y-m-d H:i:s', filemtime('upload/' . $file));
				
				$queryCheck = 'SELECT id FROM ' . $conf_mysql_prefix . 'img WHERE filename=\'' . $filename . '\'';
				$qCheck = mysql_query($queryCheck);
				$nCheck = mysql_num_rows($qCheck);
				
				if($nCheck == 0) {
					$counter++;
					
					$queryAdd = 'INSERT INTO ' . $conf_mysql_prefix . 'img SET filename=\'' . $filename . '\', filetype=\'' . $filetype . '\', filesize=\'' . $filesize . '\', filemtime=\'' . $filemtime . '\'';
					
					if(@mysql_query($queryAdd)) {
						echo '<span style="color: #090;">' . sprintf(lang('Image "%s" has been added to your image database.'), $filename) . '</span><br />' . "\n";
					}
					else {
						echo '<span style="color: #F00;">' . sprintf(lang('Could not add "%s" to your image database!'), $filename) . '</span><br />' . "\n";
					}
				}
			}
		}

		closedir($handle);
	}
	
	if($counter == 0) {
		echo lang('No new images found!');
	}

?>
		</div>
		<div class="sblog_post_options">&nbsp;</div>
	</div>
<?php
	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	mysql_close();
	
	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>