<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/mysql.php');
	
	$query = 'SELECT block_topic, block_content, block_style, block_top FROM ' . $conf_mysql_prefix . 'blocks WHERE block_vis=\'1\' ORDER BY block_pos ASC';
	
	$q = mysql_query($query);
	
	ob_start();

?>
<!-- START OF BLOCK_CUSTOM -->
<?php

	if(array_key_exists('Username', $_SESSION) && $_SESSION['Username'] == $conf_admin_username)
		require('inc/block/block_admin.php');

	while($r = mysql_fetch_assoc($q)) {
		if(preg_match("/^{(.*)}$/i", $r['block_topic'], $block)) {	
			if(file_exists('inc/block/block_' . strtolower($block[1]) . '.php')) {
				if(strtolower($block[1]) == 'admin') {
					if(!array_key_exists('Username', $_SESSION))
						require('inc/block/block_admin.php');
				}
				else
					require('inc/block/block_' . strtolower($block[1]) . '.php');
				continue;
			}
		}
		
		echo "\t\t\t" . '<div class="sblog_block">' . "\n";
		
		if(intval($r['block_top']) == 1) {
			echo "\t\t\t\t" . '<div class="sblog_block_topic">' . "\n";
			echo "\t\t\t\t\t" . '<h2 class="sblog_block_topic_text">' . htmlspecialchars(stripslashes($r['block_topic'])) . '</h2>' . "\n";
			echo "\t\t\t\t" . '</div>' . "\n";
		}

		if(intval($r['block_style']) == 1) {
			echo "\t\t\t\t" . '<div class="sblog_block_text">' . "\n";
			echo "\t\t\t\t\t" . stripslashes($r['block_content']) . "\n";
			echo "\t\t\t\t" . '</div>' . "\n";
		}
		else {
			echo "\t\t\t\t" . stripslashes($r['block_content']) . "\n";
		}
		
		echo "\t\t\t" . '</div>' . "\n";
	}

?>
			<!-- END OF BLOCK_CUSTOM -->
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_block_custom>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	mysql_close();

?>