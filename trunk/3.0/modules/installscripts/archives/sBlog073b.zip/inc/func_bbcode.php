<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	function bbcode($string) {
		global $conf_web_root;

		$pattern	=	array(
							'/\\n/',											// \n
							'/\\r/',											// \r
							'/\:\)/s',										// :)
							'/\:\|/s',										// :|
							'/\=\)/s',										// =)
							'/\=\|/s',										// =|
							'/\:\(/s',										// :(
							'/\=\(/s',										// =(
							'/\:D/is',										// :D
							'/\=D/is',										// =D
							'/\:o/is',										// :o
							'/\;\)/s',										// ;)
							'/\=\//s',										// =/
							'/\:p/is',										// :P
							'/\=p/is',										// =P
							'/\:lol\:/is',									// :lol:
							'/\:mad\:/is',									// :mad:
							'/\:roll\:/is',								// :rool:
							'/\:cool\:/is',								// :cool:
							'/\[list\](.*?)\[\/list\]/ise',			// [list]
							'/\[b\](.*?)\[\/b\]/is',					// [b]
							'/\[strong\](.*?)\[\/strong\]/is',		// [strong]
							'/\[i\](.*?)\[\/i\]/is',					// [i]
							'/\[u\](.*?)\[\/u\]/is',					// [u]
							'/\[s\](.*?)\[\/s\]/is',					// [s]
							'/\[del\](.*?)\[\/del\]/is',				// [del]
							'/\[url=(.*?)\](.*?)\[\/url\]/ise',		// [url]
							'/\[email=(.*?)\](.*?)\[\/email\]/is',	// [email]
							'/\[img](.*?)\[\/img\]/ise',				// [img]
							'/\[color=(.*?)\](.*?)\[\/color\]/is',	// [color]
							'/\[line\]/is',								// [line]
							'/\[quote\](.*?)\[\/quote\]/ise',		// [quote]
							'/\[code\](.*?)\[\/code\]/ise'			// [code]
						);
	
		$replace	=	array(
							'',																								// \n
							'',																								// \r
							'<img src="' . $conf_web_root . 'img/smilies/smile.png" alt=":)" />',		// :)
							'<img src="' . $conf_web_root . 'img/smilies/neutral.png" alt=":|" />',		// :|
							'<img src="' . $conf_web_root . 'img/smilies/smile.png" alt="=)" />',		// =)
							'<img src="' . $conf_web_root . 'img/smilies/neutral.png" alt="=|" />',		// =|
							'<img src="' . $conf_web_root . 'img/smilies/sad.png" alt=":(" />',			// :(
							'<img src="' . $conf_web_root . 'img/smilies/sad.png" alt="=(" />',			// =(
							'<img src="' . $conf_web_root . 'img/smilies/big_smile.png" alt=":D" />',	// :D
							'<img src="' . $conf_web_root . 'img/smilies/big_smile.png" alt="=D" />',	// =D
							'<img src="' . $conf_web_root . 'img/smilies/yikes.png" alt=":o" />',		// :o
							'<img src="' . $conf_web_root . 'img/smilies/wink.png" alt=";)" />',			// ;)
							'<img src="' . $conf_web_root . 'img/smilies/hmm.png" alt="=/" />',			// =/
							'<img src="' . $conf_web_root . 'img/smilies/tongue.png" alt=":p" />',		// :P
							'<img src="' . $conf_web_root . 'img/smilies/tongue.png" alt=":P" />',		// =P
							'<img src="' . $conf_web_root . 'img/smilies/lol.png" alt=":lol:" />',		// :lol:
							'<img src="' . $conf_web_root . 'img/smilies/mad.png" alt=":mad:" />',		// :mad:
							'<img src="' . $conf_web_root . 'img/smilies/roll.png" alt=":roll:" />',	// :rool:
							'<img src="' . $conf_web_root . 'img/smilies/cool.png" alt=":cool:" />',	// :cool:
							'sList(\'\\1\')',																				// [list]
							'<b>\1</b>',																					// [b]
							'<strong>\1</strong>',																		// [strong]
							'<i>\1</i>',																					// [i]
							'<span style="text-decoration: underline;">\1</span>',							// [u]
							'<span style="text-decoration: line-through;">\1</span>',						// [s]
							'<span style="text-decoration: line-through;">\1</span>',						// [del]
							'urlfix(\'\\1\',\'\\2\')',																	// [url]
							'<a href="mailto:\1" title="\1">\2</a>',												// [email]
							'imagefix(\'\\1\')',																			// [img]
							'<span style="color: \1;">\2</span>',													// [color]
							'<div class="sblog_line"></div>',														// [line]
							'sQuote(\'\1\')',																				// [quote]
							'sCode(\'\1\')'																				// [code]
						);
						
		return preg_replace($pattern, $replace, sCensor(nl2br(htmlspecialchars(sStripSlashes($string)))));
	}
	
	function sQuote($string) {
		return '<div class="sblog_quote">' . stripslashes(trim($string)) . '</div>';
	}
	
	function sCode($string){ // ugly fix to prevent smilies in [code], simply removing them again :)
		global $conf_web_root;

		$pattern =	array(		
							'/\<img src=\\\"(.*?)img\/smilies\/(.*?).png\\\" alt=\\\"(.*?)\\\" \/>/s'
						);
		
		$replace =	array(
							'\3'
						);
		
		$string = preg_replace($pattern, $replace, ($string));
		
		return '<pre class="sblog_code">' . trim($string) . '</pre>';
	}
	
	function sList($string) {
		$tmp = explode('[*]', stripslashes($string));
		$out = null;
		
		foreach($tmp as $list) {
			if(strlen(str_replace('<br />', '', $list)) > 0) {
				$out .= '<li>' . trim($list) . '</li>';
			}
		}

		return '<ul>' . $out . '</ul>';
	}
	
	function imagefix($img) {
		global $conf_web_root;

		if(substr($img, 0, 7) != 'http://') {
			// add the web root if url is relative
			$img = $conf_web_root . $img;
		}

		return '<img src="' . $img . '" alt="' . $img . '" title="' . $img . '" />';
	}
	
	function urlfix($url, $title) {
		global $conf_link_new;
		
		$title = stripslashes($title);
		
		if($conf_link_new == 1) {
			return '<a href="' . $url . '" rel="external" title="' . lang('Open link in new window') . '" class="sblog_external">' . $title . '</a>';
		}
		else {
			return '<a href="' . $url . '">' . $title . '</a>';
		}
	}

?>