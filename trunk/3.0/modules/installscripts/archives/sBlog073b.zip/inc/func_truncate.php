<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	function truncate($string, $max) {
		global $conf_trunc_pos;
		
		if(strlen($string) > $max) {
			if($conf_trunc_pos == 'center') {
				$trunc = ceil(($max - 3) / 2);
				$string = htmlspecialchars(trim(substr($string, 0, $trunc))) . '&hellip;' . htmlspecialchars(trim(substr($string, -$trunc, strlen($string))));
			}
			else {
				if(substr(trim($string), -1, 1) == '.') {
					$string = htmlspecialchars(trim(substr($string, 0, $max)));
				}
				else {
					$string = htmlspecialchars(trim(substr($string, 0, $max))) . '&hellip;';
				}
			}
		}
		else {
			$string = htmlspecialchars(trim($string));
		}
		
		return $string;
	}

?>