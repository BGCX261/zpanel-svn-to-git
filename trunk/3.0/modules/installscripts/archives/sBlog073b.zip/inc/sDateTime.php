<?php

	if(!function_exists('sDateTime')) {
		function sDateTime($timestamp, $format) {
			global $conf_time_offset;
			
			$daylight = date('I');
			
			if($conf_time_offset == 0)
				return gmstrftime(lang($format), $timestamp + (3600 * $daylight));
			else
				return gmstrftime(lang($format), $timestamp + (3600 * ($conf_time_offset + $daylight)));
		}
	}

?>