<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// function for rendering the posts
	function sRenderStatic($id, $date_created, $topic, $content, $static_style, $static_top) {
		global $conf_web_root, $conf_mysql_prefix, $conf_date;

		// define variables
		$id				= intval($id);
		$date_created	= $date_created;
		
		if(strlen($topic) > 0) {
			$topic = sStripSlashes($topic);
		}
		else {
			$topic = '-{ ' . lang('no topic') . ' }-';
		}
		
		$content = sStripSlashes($content);
		
		echo "\t\t\t" . '<!-- START OF POST -->' . "\n";
		echo "\t\t\t" . '<div class="sblog_post">' . "\n";
		
		if($static_top == 1) {
			echo "\t\t\t\t" . '<div class="sblog_post_topic"><h1 class="sblog_post_topic_text">' . htmlspecialchars($topic) . '</h1></div>' . "\n";
		}
		
		if($static_style == 1) {
			echo "\t\t\t\t" . '<div class="sblog_post_text">' . "\n";
			echo "\t\t\t\t\t" . $content . "\n";
			echo "\t\t\t\t" . '</div>' . "\n";
		}
		else {
			echo "\t\t\t\t\t" . $content . "\n";
		}
		
		echo "\t\t\t\t" . '<div class="sblog_post_options">';
		
		if($id != 0) {
			// administrator functions
			if(array_key_exists("Username", $_SESSION) && $_SESSION['Username'] != '') {
				echo '<a href="' . $conf_web_root . 'static_del.php?id=' . $id . '" title="' . lang('Delete') . '" class="sblog_post_options_link_delete">' . lang('Delete') . '</a> <a href="' . $conf_web_root . 'static_edit.php?id=' . $id . '" title="' . lang('Edit') . '" class="sblog_post_options_link_edit">' . lang('Edit') . '</a>';
			}
		}
		else {
			echo "\t\t\t\t" . '&nbsp;' . "\n";
		}
		
		echo '</div>' . "\n";
		echo "\t\t\t" . '</div>' . "\n";
		echo "\t\t\t" . '<!-- END OF POST -->' . "\n\n";

	}

?>