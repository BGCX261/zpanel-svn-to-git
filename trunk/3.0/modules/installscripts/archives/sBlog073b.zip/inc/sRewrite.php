<?php

	if(!function_exists('sRewrite')) {
		function sRewrite($type = 'archive') {
			global $conf_web_root, $conf_mod_rewrite;
			
			$url = null;
			$date = null;
			
			$args = func_get_args();
			
			for($i = 1; $i < count($args) - 1; $i += 2) {
				$$args[$i] = $args[($i + 1)];
			}

			switch($type) {
				case 'archive':
					if($conf_mod_rewrite == 1) {
						if(strlen($date) == 8) {
							$url = $conf_web_root . 'archive/' . substr($date, 0, 4) . '/' . substr($date, 4, 2) . '/' . substr($date, 6, 2) . '/';
						}
						else if(strlen($date) == 6) {
							$url = $conf_web_root . 'archive/' . substr($date, 0, 4) . '/' . substr($date, 4, 2) . '/';
						}
						else if(strlen($date) == 4) {
							$url = $conf_web_root . 'archive/' . substr($date, 0, 4) . '/';
						}
					}
					else {
						$url = $conf_web_root . 'index.php?date=' . $date;
					}
					break;
				case 'category':
					if($conf_mod_rewrite == 1) {
						$url = $conf_web_root . 'category/' . $cat . '/';
					}
					else {
						$url = $conf_web_root . 'index.php?cat=' . $cat;
					}
					break;
				case 'article':
					if($conf_mod_rewrite == 1) {
						if(isset($anchor) && intval($anchor) != 0) {
							$url = $conf_web_root . 'article/' . $id . '/#' . $anchor;
						}
						else {
							$url = $conf_web_root . 'article/' . $id . '/';
						}
					}
					else {
						if(isset($anchor) && intval($anchor) != 0) {
							$url = $conf_web_root . 'blog.php?id=' . $id . '#' . $anchor;
						}
						else {
							$url = $conf_web_root . 'blog.php?id=' . $id;
						}
					}
					break;
				case 'static':
					if($conf_mod_rewrite == 1) {
						$url = $conf_web_root . 'page/' . $id . '/';
					}
					else {
						$url = $conf_web_root . 'static_page.php?id=' . $id;
					}
					break;
				case 'comments':
					if($conf_mod_rewrite == 1) {
						$url = $conf_web_root . 'comments/' . $id . '/#comments';
					}
					else {
						$url = $conf_web_root . 'comments.php?id=' . $id . '#comments';
					}
					break;
				case 'trackback':
					if($conf_mod_rewrite == 1) {
						$url = $conf_web_root . 'trackback/' . $id . '/';
					}
					else {
						$url = $conf_web_root . 'trackback.php?blog_id=' . $id;
					}
					break;
				default:
					break;
			}
			
			return $url;
		}
	}

?>