<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	ob_start();
	
?>
<a href="http://servous.se/" rel="external" title="Powered by sBLOG"><img src="<?php echo $conf_web_root; ?>img/sblog_80x15.png" alt="Powered by sBLOG" /></a> <a href="http://validator.w3.org/check?verbose=1&amp;uri=<?php echo $conf_web_root . basename($_SERVER['PHP_SELF']); ?>" rel="external" title="Valid XHTML 1.0 Strict"><img src="<?php echo $conf_web_root; ?>img/xhtml10.png" alt="XHTML 1.0 Strict" /></a> <a href="http://php.net/" rel="external" title="Powered by PHP"><img src="<?php echo $conf_web_root; ?>img/php.png" alt="PHP" /></a> <a href="http://jigsaw.w3.org/css-validator/validator?profile=css2&amp;warning=2&amp;uri=<?php echo $conf_web_root; ?>" rel="external" title="Valid CSS"><img src="<?php echo $conf_web_root; ?>img/css.png" alt="CSS" /></a><br />
<?php

	if(!isset($conf_local_time_vis) || intval($conf_local_time_vis) == 1) {
		echo "\t\t" . lang('Local time') . ': ' . sDateTime(gmmktime(gmdate('H'), gmdate('i'), gmdate('s'), gmdate('m'), gmdate('d'), gmdate('Y')), $conf_date) . ' GMT';
		
		if($conf_time_offset != 0) {
			echo $conf_time_offset;
		}
		
		echo '<br />' . "\n";
	}

	if(!isset($conf_version_vis) || intval($conf_version_vis) == 1) {
		echo "\t\t" . 'Version ' . $conf_current_version . ' (Build ' . $conf_current_build . ')<br />' . "\n";
	}

?>		
		Powered by <a href="http://servous.se/" rel="external" title="sBLOG" class="sblog_copy">sBLOG</a> &copy; 2005 Servous
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_copy>', $tpl_temp, $tpl_main);
	
	ob_end_clean();

?>