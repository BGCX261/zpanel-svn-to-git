<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	if(!session_id()) {
		session_start();
	}

	// include configuration file
	require('inc/config.php');
	
	// get template
	$tpl_main = file_get_contents($conf_doc_root . "template/static.tpl");

	// include headers
	require('inc/headers.php');

?>