<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/
	
	require('inc/config.php');
	require('inc/lang.php');

	/* start <sblog_menu> */
	ob_start();
	
?>
	<!-- MENU START -->
	<div id="sblog_menu">
<?php

	require('inc/mysql.php');

	$queryMenu = 'SELECT menu_title, menu_description, menu_url FROM ' . $conf_mysql_prefix . 'menu WHERE menu_vis=\'1\' ORDER BY menu_pos';
	$qMenu = mysql_query($queryMenu);
	$nMenu = mysql_num_rows($qMenu);

	if($nMenu > 0) {
		echo "\t\t" . '<ul>' . "\n";

		while($rMenu = mysql_fetch_assoc($qMenu)) {
			if($rMenu['menu_url'] == 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']) {
				$class = ' class="sblog_menu_current"';
			}
			else {
				$class = null;
			}
			
			echo "\t\t\t" . '<li' . $class . '><a href="' . $rMenu['menu_url'] . '" title="' . $rMenu['menu_description'] . '">' . $rMenu['menu_title'] . '</a></li>' . "\n";
		}

		echo "\t\t" . '</ul>' . "\n";
	}
	
	mysql_close();

?>
	</div>
	<!-- MENU END -->
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_menu>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_menu> */

?>