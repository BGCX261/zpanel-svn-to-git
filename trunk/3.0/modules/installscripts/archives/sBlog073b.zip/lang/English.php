<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

		Language	Swedish
		Author	Servous <servous@gmail.com>
		Edited	2005-11-17, Servous <servous@gmail.com>

	 **************************************************/

	// set locale
	setlocale(LC_ALL, 'en_US', 'enu');

	// character set
	$charset = 'iso-8859-1';

	$lang =	array(
					// Blocks
					'Administrator' => '',
					'Archive' => '',
					'Calendar' => '',
					'Comments' => '',
					'Latest posts' => '',
					'Links' => '',
					'Search' => '',
					'Style' => '',
					'Syndication' => '',
					
					// Calendar
					'Friday' => '',
					'Monday' => '',
					'Saturday' => '',
					'Sunday' => '',
					'Thursday' => '',
					'Tuesday' => '',
					'Wednesday' => '',

					// Buttons
					'Cancel' => '',
					'Create' => '',
					'Go back' => '',
					'Help' => '',
					'OK' => '',
					'Preview' => '',
					'Publish' => '',
					'Search posts' => '',
					'Upload image' => '',
					
					// Menu
					'Add menu item' => '',
					'Categories' => '',
					'Censoring' => '',
					'Choose from static pages' => '',
					'Enter URL' => '',
					'Existing menu items' => '',
					'Links' => '',
					'Login' => '',
					'Logout' => '',
					'Make this menu item visible for visitors' => '',
					'Menu URL' => '',
					'Menu description' => '',
					'Menu settings' => '',
					'Menu topic' => '',
					'Menu' => '',
					'Posts' => '',
					'Settings' => '',
					'Use style logo' => '',
					
					// Upgrade
					'Check for upgrade' => '',
					'Could not fetch information from server!' => '',
					'Download' => '',
					'Error' => '',
					'New version of sBLOG available!' => '',
					'No new version available.' => '',
					'Please try again later.' => '',
					'You are using the latest version of sBLOG.' => '',
					
					// Messages
					'Administrator\'s password has been updated.' => '',
					'Administrator\'s username has been updated.' => '',
					'Change the administrator\'s username and password.' => '',
					'Could NOT update administrator\'s password!' => '',
					'Could not update administrator\'s username!' => '',
					'ERROR: Invalid username!' => '',
					'Invalid username' => '',
					'Passwords doesn\'t match!' => '',
					'The post has been deleted!' => '',
					'Wrong password!' => '',
					
					// Posts
					'Create post' => '',
					'Delete post?' => '',
					'Edited' => '',
					'Existing posts' => '',
					'post(s)' => '',
					
					// Static pages
					'Are you sure you want to delete this page?' => '',
					'Create static page' => '',
					'Delete static page?' => '',
					'Existing static pages' => '',
					'Show topic' => '',
					'Static pages' => '',
					'Use style' => '',
					
					// Comments
					'Comment' => '',
					'Homepage' => '',
					'In order to submit your comment you will have to type in the code below in the text field. The code may contain both letters and digits.' => '',
					
					// Images
					'Create folder' => '',
					'Dimensions' => '',
					'Do not resize uploaded image' => '',
					'Done. %u image(s) were deleted.' => '',
					'Existing images' => '',
					'Filesize' => '',
					'Folder' => '',
					'Folders' => '',
					'If you change the filename of an image, you may need to update posts linking to this file!' => '',
					'Image database' => '',
					'Images' => '',
					'Make sure you add the correct file extension to the image (.JPG, .PNG or .GIF).' => '',
					'Move here' => '',
					'Move to folder' => '',
					'Prune' => '',
					'Rename file to' => '',
					'Rename' => '',
					'Scan' => '',
					'This image is used in the following post(s)' => '',
					'Uploaded' => '',

					// Categories
					'Add new category' => '',
					'Categories' => '',
					'Category' => '',
					'Existing categories' => '',
					
					// Links
					'Add link' => '',
					'Existing links' => '',
					'Link URL' => '',
					'Link title' => '',
					
					// Censoring
					'Add word' => '',
					'Existing words' => '',
					'Replace with' => '',
					'Word' => '',

					// Blocks
					'Block content' => '',
					'Block positions' => '',
					'Block settings' => '',
					'Block topic' => '',
					'Blocks' => '',
					'Built in blocks' => '',
					'Create block' => '',
					'Delete block?' => '',
					'Make the block visible for visitors' => '',
					'Position' => '',
					'Show block topic' => '',
					'This field is not parsed as regular posts and may thus contain HTML tags.' => '',
					'Update positions' => '',
					'Use block style' => '',
					
					// Settings
					'Count posts in "%s" block' => '',
					'Count posts' => '',
					'Current password' => '',
					'Date and Time' => '',
					'Display version' => '',
					'Download language files' => '',
					'Download new styles' => '',
					'E-mail' => '',
					'Enable user comments' => '',
					'General' => '',
					'Language' => '',
					'Limits' => '',
					'Max number of characters in blocks.' => '',
					'Max. image width (in pixels). This requires GD to work.' => '',
					'Number of posts to syndicate.' => '',
					'Number of rows in "%s"' => '',
					'Open link in new window' => '',
					'Open links in a new window.' => '',
					'Page description' => '',
					'Page title' => '',					
					'Posts per page' => '',
					'Save' => '',
					'Send me e-mails when new comments are posted.' => '',
					'Show local time' => '',
					'Truncate long text from the' => '',
					'Truncate' => '',
					'Verify new password' => '',
					'Version' => '',
					
					// Pages
					'First' => '',
					'Last' => '',
					'Next' => '',
					'Page' => '',
					'Previous' => '',
					
					// Actions
					'Delete' => '',
					'Edit' => '',

					// Miscellaneous
					'Add comment' => '',
					'Are you sure you want to continue?' => '',
					'Are you sure you want to delete this block?' => '',
					'Are you sure you want to delete this post?' => '',
					'Blocks' => '',
					'Comments' => '',
					'Content' => '',
					'Could not create category!' => '',
					'Could not delete the category!' => '',
					'Default' => '',
					'Document root' => '',
					'Draft' => '',
					'ERROR' => '',
					'Enable URL rewriting' => '',
					'Enable syndication' => '',
					'Enable trackbacks' => '',
					'Error(s)' => '',
					'Example' => '',
					'File "%s" does not exist!' => '',
					'Filename' => '',
					'Image "%s" has been added to your image database.' => '',
					'Left' => '',
					'Local time' => '',
					'Message(s)' => '',
					'Messages' => '',
					'Middle' => '',
					'Miscellaneous' => '',
					'Name' => '',
					'New folder' => '',
					'New password' => '',
					'No new images found!' => '',
					'No posts were posted on this date.' => '',
					'No topic' => '',
					'Not assigned to any post(s).' => '',
					'Options' => '',
					'Password' => '',
					'Permalink' => '',
					'Permalinks' => '',
					'Post comment' => '',
					'Posted' => '',
					'Read more' => '',
					'Remember me for a week.' => '',
					'Rename' => '',
					'Right' => '',
					'Send trackback pings to the following URLs (one URL per row)' => '',
					'Server' => '',
					'Show/Hide' => '',
					'Silent edit' => '',
					'Smilies' => '',
					'Syndicate' => '',
					'Text formatting' => '',
					'Text' => '',
					'The category has been created.' => '',
					'The category was successfully deleted.' => '',
					'The search string is too short!' => '',
					'There are no posts assigned to this category.' => '',
					'This action will delete unused images!' => '',
					'This is a preview. Your changes has not been saved yet!' => '',
					'Time Zone' => '',
					'To make this work you must have %s installed on your server. (If you\'re not sure, leave this box unchecked.)' => '',
					'Topic' => '',
					'Trackback URL for this post' => '',
					'Trackback ping' => '',
					'Trackbacks' => '',
					'Uncategorized' => '',
					'Upload' => '',
					'Username' => '',
					'Web root' => '',
					'You can now access it from the image list.' => '',
					'Your image was successfully uploaded.' => '',
					'Your search for "%s" did not return any matches!' => '',
					'of' => ''
				);

?>