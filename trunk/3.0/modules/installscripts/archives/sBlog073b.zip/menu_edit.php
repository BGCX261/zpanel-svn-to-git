<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	
	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks
	
	if(array_key_exists('id', $_GET) && intval($_GET['id']) != 0) {
		$id = intval($_GET['id']);
		
		require('inc/mysql.php');
		
		$query = 'SELECT id, menu_title, menu_description, menu_url, menu_vis FROM ' . $conf_mysql_prefix . 'menu WHERE id=\'' . $id . '\' LIMIT 1';
		
		$q = mysql_query($query);
		$r = mysql_fetch_assoc($q);
		
		mysql_close();
		
		$menu_title = $r['menu_title'];
		$menu_description = $r['menu_description'];
		$menu_url = $r['menu_url'];
		$menu_vis = intval($r['menu_vis']);
	}
	else {
		$id = null;
		$menu_title = null;
		$menu_description = null;
		$menu_url = null;
		$menu_vis = 0;
	}
	
	ob_start();
	
?>

			<div class="sblog_post">
			<div class="sblog_post_topic">
				<h1><?php echo lang('Add menu item'); ?></h1>
			</div>
			<div class="sblog_post_text">
				<form id="menu_edit" method="post" action="menu_edit_do.php">
					<div>
					<input type="button" value="<?php echo lang('Cancel'); ?>" onclick="javascript:location.href='menu_pos.php';return false" class="sblog_button" />
<?php

	if(isset($id)) {

?>
					<input type="button" value="<?php echo lang('Delete'); ?>" onclick="javascript:location.href='menu_del.php?id=<?php echo $id; ?>';return false" class="sblog_button" />
<?php

	}

?>
					<input type="submit" value="<?php echo lang('Save'); ?>" class="sblog_button" /><br /><br />
				</div>
				<fieldset>
					<input type="hidden" name="id" value="<?php echo $id; ?>" />
					<legend><?php echo lang('Menu topic'); ?></legend>
					<input type="text" name="menu_title" id="menu_title" value="<?php echo htmlspecialchars(sStripSlashes($menu_title)); ?>" class="sblog_input" />
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Menu description'); ?></legend>
					<input type="text" name="menu_description" id="menu_description" maxlength="255" value="<?php echo htmlspecialchars(sStripSlashes($menu_description)); ?>" class="sblog_input" />
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Menu URL'); ?></legend>
<?php

	require('inc/mysql.php');

	$queryStatic = 'SELECT id, topic FROM ' . $conf_mysql_prefix . 'static WHERE draft=\'0\' ORDER BY topic ASC';
	$qStatic = mysql_query($queryStatic);
	$nStatic = mysql_num_rows($qStatic);

	if($nStatic > 0) {
		echo "\t\t\t\t\t" . lang('Choose from static pages') . '<br />' . "\n";
		echo "\t\t\t\t\t" . '<select name="static_pages" onchange="javascript:document.getElementById(\'menu_url\').value=this.options[selectedIndex].value;">' . "\n";
		echo "\t\t\t\t\t\t" . '<option value=""></option>' . "\n";
		
		while($rStatic = mysql_fetch_assoc($qStatic)) {
			echo "\t\t\t\t\t\t" . '<option value="' . sRewrite('static', 'id', $rStatic['id']) . '">' . $rStatic['topic'] . '</option>' . "\n";
		}
		
		echo "\t\t\t\t\t" . '</select><br /><br />' . "\n";
	}
	
	mysql_close();

?>
					<?php echo lang('Enter URL'); ?><br />
					<input type="text" name="menu_url" id="menu_url" size="64" value="<?php echo htmlspecialchars(sStripSlashes($menu_url)); ?>" class="sblog_input" />
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Menu settings'); ?></legend>
<?php

	if($menu_vis == 1) {
		$checked = ' checked="checked"';
	}
	else {
		$checked = null;
	}

?>
					<label for="menu_vis"><input type="checkbox" name="menu_vis" id="menu_vis" value="1"<?php echo $checked; ?> /> <?php echo lang('Make this menu item visible for visitors'); ?></label><br />
				</fieldset>
				</form>
			</div>
			<div class="sblog_post_options">&nbsp;</div>
		</div>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */
	
	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>