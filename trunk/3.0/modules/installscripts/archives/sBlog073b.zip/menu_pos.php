<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');

	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks

	ob_start();
	
?>

			<div class="sblog_post">
			<div class="sblog_post_topic">
				<h1><?php echo lang('Menu'); ?></h1>
			</div>
			<div class="sblog_post_text">
				<form id="custom_menu" method="post" action="menu_pos_do.php">
				<div>
				<input type="button" value="<?php echo lang('Add menu item'); ?>" onclick="javascript:location.href='menu_edit.php';return false" class="sblog_button" />
				<input type="submit" value="<?php echo lang('Update positions'); ?>" class="sblog_button" /><br /><br />
			</div>
				<fieldset>
					<legend><?php echo lang('Existing menu items'); ?></legend>
<?php

	require('inc/mysql.php');

	$query = 'SELECT id, menu_title, menu_description, menu_pos, menu_vis FROM ' . $conf_mysql_prefix . 'menu ORDER BY menu_pos ASC';
	
	$q = mysql_query($query);
	
	while($r = mysql_fetch_assoc($q)) {
		
		// fancy topics
		if(strlen($r['menu_title']) > 0) {
			if(substr($r['menu_title'], 0, 1) == '{' && substr($r['menu_title'], -1) == '}') {
				$topic = $r['menu_title'];
			}
			else {
				$topic = '<strong>' . $r['menu_title'] . '</strong>';
			}
		}
		else {
			$topic = '<strong><i>' . lang('no topic') . '</i></strong>';
		}
		
		// which boxes to check
		if(intval($r['menu_vis']) == 1) {
			$checked = ' checked="checked"';
		}
		else {
			$checked = null;
		}

		echo "\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
		echo "\t\t\t\t\t\t" . '<input type="checkbox" name="vis[' . $r['id'] . ']" value="1"' . $checked . ' title="' . lang('Show/Hide') . '" />' . "\n";
		echo "\t\t\t\t\t\t" . '<a href="menu_edit.php?id=' . $r['id'] . '">' . lang('Edit') . '</a>' . "\n";
		echo "\t\t\t\t\t" . '</div>' . "\n";
		echo "\t\t\t\t\t" . '<div class="sblog_val">' . "\n";
		echo "\t\t\t\t\t\t" . lang('Position') . ': <input type="text" name="pos[' . $r['id'] . ']" value="' . $r['menu_pos'] . '" size="3" maxlength="5" class="sblog_input" />' . "\n";
		echo "\t\t\t\t\t\t" . $topic . "\n";
		echo "\t\t\t\t\t" . '</div>' . "\n";
	}
	
	mysql_close();

?>
				</fieldset>
				</form>
			</div>
			<div class="sblog_post_options">&nbsp;</div>
			</div>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */
	
	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>