<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('config.php');
	require('inc/config.php');
	require('inc/func_config_update.php');
	require('inc/mysql.php');

	// PERSONAL
	if(array_key_exists('admin_email', $_POST)) {
		sblog_config_update('conf_admin_email', mysql_real_escape_string($_POST['admin_email']));
	}
	
	$comments_email = (array_key_exists('comments_email', $_POST) && intval($_POST['comments_email']) > 0) ? 1 : 0 ;
	sblog_config_update('conf_comments_email', $comments_email);
	
	$comments_act = (array_key_exists('comments_act', $_POST) && intval($_POST['comments_act']) > 0) ? 1 : 0;
	sblog_config_update('conf_comments_act', $comments_act);
	
	$trackback_act = (array_key_exists('trackback_act', $_POST) && intval($_POST['trackback_act']) > 0) ? 1 : 0;
	sblog_config_update('conf_trackback_act', $trackback_act);
	
	$syndicate_act = (array_key_exists('syndicate_act', $_POST) && intval($_POST['syndicate_act']) > 0) ? 1 : 0;
	sblog_config_update('conf_syndicate_act', $syndicate_act);

	// PAGE
	sblog_config_update('conf_page_title', mysql_real_escape_string($_POST['page_title']));
	
	$style_logo = (array_key_exists('style_logo', $_POST)) ? 1 : 0 ;
	sblog_config_update('conf_style_logo', $style_logo);
	
	sblog_config_update('conf_page_description', mysql_real_escape_string($_POST['page_description']));

	// LIMITS
	if(array_key_exists('page_disp', $_POST)) {
		sblog_config_update('conf_page_disp', intval($_POST['page_disp']));
	}
	
	if(array_key_exists('bar_latest_disp', $_POST)) {
		sblog_config_update('conf_bar_latest_disp', intval($_POST['bar_latest_disp']));
	}
	
	if(array_key_exists('bar_comments_disp', $_POST)) {
		sblog_config_update('conf_bar_comments_disp', intval($_POST['bar_comments_disp']));
	}
	
	if(array_key_exists('img_width', $_POST)) {
		sblog_config_update('conf_img_width', intval($_POST['img_width']));
	}
	
	if(array_key_exists('block_chars', $_POST)) {
		sblog_config_update('conf_block_chars', intval($_POST['block_chars']));
	}
	
	if(array_key_exists('syndicate_limit', $_POST)) {
		sblog_config_update('conf_syndicate_limit', intval($_POST['syndicate_limit']));
	}
	
	// DATE AND TIME
	sblog_config_update('conf_date', mysql_real_escape_string($_POST['conf_date']));
	sblog_config_update('conf_time_offset', mysql_real_escape_string($_POST['time_offset']));

	// STYLE
	sblog_config_update('conf_style_default', mysql_real_escape_string($_POST['style_default']));

	// LANGUAGE
	sblog_config_update('conf_lang_default', mysql_real_escape_string($_POST['lang_default']));
	
	// LINKS
	$link_new = (array_key_exists('link_new', $_POST)) ? 1 : 0;
	sblog_config_update('conf_link_new', $link_new);
	
	$mod_rewrite = (array_key_exists('mod_rewrite', $_POST) && intval($_POST['mod_rewrite']) > 0) ? 1 : 0 ;
	sblog_config_update('conf_mod_rewrite', $mod_rewrite);
	
	// MISC
	$expert = (array_key_exists('expert', $_POST)) ? 1 : 0;
	sblog_config_update('conf_expert', $expert);

	$version_vis = (array_key_exists('version_vis', $_POST) && intval($_POST['version_vis']) > 0) ? 1 : 0;
	sblog_config_update('conf_version_vis', $version_vis);
	
	$local_time_vis = (array_key_exists('local_time_vis', $_POST)) ? 1 : 0 ;
	sblog_config_update('conf_local_time_vis', $local_time_vis);
	
	$count_posts_vis = (array_key_exists('count_posts_vis', $_POST)) ? 1 : 0;
	sblog_config_update('conf_count_posts_vis', $count_posts_vis);
	
	sblog_config_update('conf_trunc_pos', $_POST['trunc_pos']);

	mysql_close();
	
	header("Location: settings.php");
	exit;

?>