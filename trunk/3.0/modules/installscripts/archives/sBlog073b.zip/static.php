<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');

	// include blocks
	require('inc/block_custom.php');			// custom blocks

	/* start <sblog_main> */
	ob_start();

?>
				<div class="sblog_post">
				<div class="sblog_post_topic">
					<h1><?php echo lang('Static pages'); ?></h1>
				</div>
				<div class="sblog_post_text">
					<form id="static" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<div>
						<input type="button" value="<?php echo lang('Create static page'); ?>" onclick="javascript:location.href='static_edit.php'" class="sblog_button" /><br /><br />
					</div>
<?php

	if(!function_exists('truncate')) {
		require('inc/func_truncate.php');
	}

	require('inc/mysql.php');

	$query = 'SELECT id, UNIX_TIMESTAMP(date_created) AS date_created, topic, draft FROM ' . $conf_mysql_prefix . 'static ORDER BY draft DESC, date_created DESC';
	
	$q = mysql_query($query);
	$n = mysql_num_rows($q);
	
	if($n > 0) {
		$counter = 0;
		
		// set active page
		if(!isset($_GET['p'])) {
			$page = 1;
		}
		else {
			$page = $_GET['p'];
		}

		// prevent division by zero error
		if(isset($conf_page_disp) && $conf_page_disp > 0) {
			$pages = ceil($n / 10);
		}
		else {
			$conf_page_disp = 5;
			$pages = 0;
		}

		// jump to active page in database
		mysql_data_seek($q, (($page - 1) * 10));

		echo "\t\t\t\t\t" . '<fieldset>' . "\n";
		echo "\t\t\t\t\t\t" . '<legend>' . lang('Existing static pages') . '</legend>' . "\n";

		while($r = mysql_fetch_assoc($q)) {
			$counter++;
			
			if($counter > 10) {
				break;
			}
			
			echo "\t\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
			echo "\t\t\t\t\t\t\t" . '<a href="static_del.php?id=' . $r['id'] . '">' . lang('Delete') . '</a>' . "\n";
			echo "\t\t\t\t\t\t\t" . '<a href="static_edit.php?id=' . $r['id'] . '">' . lang('Edit') . '</a>' . "\n";
			echo "\t\t\t\t\t\t" . '</div>' . "\n";
			echo "\t\t\t\t\t\t" . '<div class="sblog_val">' . "\n";

			if($r['draft'] == 1) {
				echo "\t\t\t\t\t\t\t" . truncate($r['topic'], 32) . '<br />' . "\n";
				echo "\t\t\t\t\t\t\t" . '<strong>' . lang('Draft') . '</strong>' . "\n";
			}
			else {
				echo "\t\t\t\t\t\t\t" . '<a href="' . sRewrite('static', 'id', $r['id']) . '"><strong>' . truncate($r['topic'], 32) . '</strong></a><br />' . "\n";
				echo "\t\t\t\t\t\t\t" . lang('Created') . ': ' . sDateTime($r['date_created'], $conf_date) . "\n";
			}
			
			echo "\t\t\t\t\t\t" . '</div>' . "\n";
		}
		echo "\t\t\t\t\t" . '</fieldset>' . "\n";

?>
				</form>
			</div>
			<div class="sblog_post_options">&nbsp;</div>
			</div>
<?php

		if($pages > 1) {
			echo "\t\t\t" . '<!-- START OF PAGES -->' . "\n";
			echo "\t\t\t" . '<div class="sblog_pages">' . "\n";
			echo "\t\t\t\t" . '<div class="sblog_pages_prev">' . "\n";
			
			if($page > 1) {
				echo "\t\t\t\t\t" . '<a href="' . $_SERVER['PHP_SELF'] . '?p=1">&laquo; ' . lang('First') . '</a> <a href="' . $_SERVER['PHP_SELF'] . '?p=' . ($page - 1) . '">&laquo; ' . lang('Previous') . '</a>' . "\n";
			}
			else {
				echo "\t\t\t\t\t" . '&laquo; ' . lang('First') . ' &laquo; ' . lang('Previous') . "\n";
			}
			
			echo "\t\t\t\t" . '</div>' . "\n";
			echo "\t\t\t\t" . '<div class="sblog_pages_next">' . "\n";
			
			if($page < $pages) {
				echo "\t\t\t\t\t" . '<a href="' . $_SERVER['PHP_SELF'] . '?p=' . ($page + 1) . '">' . lang('Next') . ' &raquo;</a> <a href="' . $_SERVER['PHP_SELF'] . '?p=' . $pages . '">' . lang('Last') . ' &raquo;</a>' . "\n";
			}
			else {
				echo "\t\t\t\t\t" . lang('Next') . ' &raquo; ' . lang('Last') . ' &raquo;' . "\n";
			}
			
			echo "\t\t\t\t" . '</div>' . "\n";
			echo "\t\t\t\t" . '<div class="sblog_pages_current">' . "\n";
			echo "\t\t\t\t\t" . $page . ' ' . lang('of') . ' ' . $pages . "\n";
			echo "\t\t\t\t" . '</div>' . "\n";
			echo "\t\t\t" . '</div>' . "\n";
			echo "\t\t\t" . '<!-- END OF PAGES -->' . "\n";
		}
	}

	mysql_close();

?>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */
	
	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>