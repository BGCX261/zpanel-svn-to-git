<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');

	if(isset($_REQUEST['id']) && $_REQUEST['id'] != '' && !array_key_exists('content', $_REQUEST)) {
		
		$id = intval($_REQUEST['id']);

		require('inc/config.php');
		require('inc/mysql.php');
		
		$query = 'SELECT UNIX_TIMESTAMP(date_created) AS date_created, topic, content, draft, static_style, static_top FROM ' . $conf_mysql_prefix . 'static WHERE id=\'' . $id . '\' LIMIT 1';
		
		$q = mysql_query($query);
		$r = mysql_fetch_assoc($q);
		
		mysql_close();
		
		$topic			= sStripSlashes($r['topic']);
		$content			= sStripSlashes($r['content']);
		$date_created	= date('YmdHis', $r['date_created']);
		$date_modified = date('YmdHis', time());
		$draft			= intval($r['draft']);
		$static_style	= intval($r['static_style']);
		$static_top		= intval($r['static_top']);
	}
	else if(array_key_exists('content', $_POST)) {
		if(array_key_exists('id', $_POST)) {
			$id = intval($_POST['id']);
		}
		else {
			$id = null;
		}
		
		$topic			= sStripSlashes($_POST['topic']);
		$content			= sStripSlashes($_POST['content']);
		
		if(strlen($_POST['date_created']) == 14) {
			$date_created = $_POST['date_created'];
		}
		else {
			$date_created = date('YmdHis');
		}
		
		if(array_key_exists('draft', $_POST) && intval($_POST['draft']) > 0) {
			$draft = 1;
		}
		else {
			$draft = null;
		}

		if(array_key_exists('static_style', $_POST)) {		
			$static_style = intval($_POST['static_style']);
		}
		else {
			$static_style = null;
		}
		
		if(array_key_exists('static_top', $_POST)) {
			$static_top = intval($_POST['static_top']);
		}
		else {
			$static_top = null;
		}
	}
	else {
		$id				= null;
		$topic			= null;
		$content			= null;
		$date_created	= null;
		$date_modified = null;
		$draft			= null;
		$static_style	= 1;
		$static_top		= 1;
	}

	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks

	ob_start();

?>
	<!-- EDIT -->
<?php

	if(array_key_exists('topic', $_REQUEST)) {
		
		require('inc/mysql.php');
		require('inc/sRenderStatic.php');
		
		if(!function_exists('truncate')) {
			require('inc/func_truncate.php');
		}
		
		echo "\t\t" . '<div class="sblog_post">' . "\n";
		echo "\t\t\t" . '<div style="background-color: #FEE; color: #F00; font-weight: bold; text-align: center; padding: 10px; border: 2px #F00 solid;">' . lang('This is a preview. Your changes has not been saved yet!') . '</div>' . "\n";
		echo "\t\t" . '</div>' . "\n";

		sRenderStatic($id, $date_created, $topic, $content, $static_style, $static_top);
		
		mysql_close();

	}

?>
			<div class="sblog_post">
			<div class="sblog_post_topic">
				<h1><?php echo lang('Create static page'); ?></h1>
			</div>
			<div class="sblog_post_text">
			<form id="edit" method="post" action="static_edit_do.php">
				<div>
					<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
					<input type="hidden" name="ref" id="ref" value="<?php echo $_SERVER['PHP_SELF']; ?>" />
					<input type="hidden" name="date_created" id="date_created" value="<?php echo $date_created; ?>" />
					<input type="button" value="<?php echo lang('Cancel'); ?>" onclick="javascript:location.href='index.php';return false" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Preview'); ?>" tabindex="3" accesskey="p" onclick="document.getElementById('edit').action='<?php echo $_SERVER['PHP_SELF']; ?>'" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Draft'); ?>" onclick="javascript:document.getElementById('draft').value=1;submit();" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Publish'); ?>" tabindex="4" accesskey="s" onclick="javascript:document.getElementById('draft').value=0;document.getElementById('edit').action='static_edit_do.php'" class="sblog_button" /><br /><br />
				</div>
				<fieldset>
					<legend><?php echo lang('Topic'); ?></legend>
					<input type="text" name="topic" id="topic" size="40" value="<?php echo htmlspecialchars($topic); ?>" tabindex="1" class="sblog_input" />
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Content'); ?></legend>
					<textarea name="content" id="content" tabindex="2" cols="40" rows="10" class="sblog_text"><?php echo htmlspecialchars($content); ?></textarea><br />
					<?php echo lang('This field is not parsed as regular posts and may thus contain HTML tags.'); ?>
<?php

	if(isset($silent) && $silent == 1) {
		$checked = ' checked="checked"';
	}
	else {
		$checked = null;
	}

?>
					<input type="hidden" name="draft" id="draft" value="0" />
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Settings'); ?></legend>
<?php

	if($static_style == 1) {
		$checked = ' checked="checked"';
	}
	else {
		$checked = null;
	}

?>
					<label for="static_style"><input type="checkbox" name="static_style" id="static_style" value="1"<?php echo $checked; ?> /> <?php echo lang('Use style'); ?></label><br />
<?php

	if($static_top == 1) {
		$checked = ' checked="checked"';
	}
	else {
		$checked = null;
	}

?>
					<label for="static_top"><input type="checkbox" name="static_top" id="static_top" value="1"<?php echo $checked; ?> /> <?php echo lang('Show topic'); ?></label><br />
				</fieldset>
				<div>
					<br /><input type="button" value="<?php echo lang('Cancel'); ?>" onclick="javascript:location.href='index.php';return false" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Preview'); ?>" tabindex="3" accesskey="p" onclick="document.getElementById('edit').action='<?php echo $_SERVER['PHP_SELF']; ?>'" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Draft'); ?>" onclick="javascript:document.getElementById('draft').value=1;submit();" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Publish'); ?>" tabindex="4" accesskey="s" onclick="javascript:document.getElementById('draft').value=0;document.getElementById('edit').action='static_edit_do.php'" class="sblog_button" /><br /><br />
				</div>
			</form>
			</div>
			<div class="sblog_post_options">&nbsp;</div>
			</div>

			<script type="text/javascript">document.getElementById('topic').focus();</script>

<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();

	require('inc/tpl_foot.php');

	echo $tpl_main;

?>