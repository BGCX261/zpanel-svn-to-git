<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// admin only
	require('inc/auth.php');

	// some important stuff
	require('inc/config.php');
	require('inc/sPing.php');
	require('inc/func_truncate.php');
	require('inc/func_bbcode_strip.php');

	// update post
	if(array_key_exists('id', $_POST) && intval($_POST['id']) > 0) {
		require('inc/mysql.php');

		$id				= intval($_POST['id']);
		$topic			= mysql_real_escape_string(sStripSlashes($_POST['topic']));
		$content			= mysql_real_escape_string(sStripSlashes($_POST['content']));

		if(array_key_exists('date_created', $_POST) && strlen($_POST['date_created']) == 14) {
			$date_created = $_POST['date_created'];
		}
		else {
			$date_created = gmdate('YmdHis');
		}
		
		if(array_key_exists('draft', $_POST) && intval($_POST['draft']) > 0) {
			$draft = 1;
		}
		else {
			$draft = 0;
		}
		
		if(array_key_exists('static_style', $_POST)) {
			$static_style = 1;
		}
		else {
			$static_style = 0;
		}
		
		if(array_key_exists('static_top', $_POST)) {
			$static_top = 1;
		}
		else {
			$static_top = 0;
		}

		$query = 'UPDATE ' . $conf_mysql_prefix . 'static SET date_modified=\'' . $date_created . '\', topic=\'' . $topic . '\', content=\'' . $content . '\', draft=\'' . $draft . '\', static_style=\'' . $static_style . '\', static_top=\'' . $static_top . '\' WHERE id=\'' . $id . '\' LIMIT 1';

		mysql_query($query);
		mysql_close();
		
	}
	// insert post
	else {
		require('inc/mysql.php');

		$topic			= mysql_real_escape_string(sStripSlashes($_POST['topic']));
		$content			= mysql_real_escape_string(sStripSlashes($_POST['content']));

		if(array_key_exists('draft', $_POST) && intval($_POST['draft']) > 0) {
			$draft = 1;
		}
		else {
			$draft = 0;
		}
		
		if(array_key_exists('static_style', $_POST) && intval($_POST['static_style']) > 0) {
			$static_style = 1;
		}
		else {
			$static_style = 0;
		}

		if(array_key_exists('static_top', $_POST) && intval($_POST['static_top']) > 0) {
			$static_top = 1;
		}
		else {
			$static_top = 0;
		}

		$query = 'INSERT INTO ' . $conf_mysql_prefix . 'static SET date_created=NOW(), topic=\'' . $topic . '\', content=\'' . $content. '\', draft=\'' . $draft . '\'';
		
		mysql_query($query);
		
		$id = mysql_insert_id();

		mysql_close();
	}

	if($draft == 1) {
		header('Location: static.php');
		exit;
	}
	else {
		header('Location: ' . sRewrite('static', 'id', $id));
		exit;
	}

?>