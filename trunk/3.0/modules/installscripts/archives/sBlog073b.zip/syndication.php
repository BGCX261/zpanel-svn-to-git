<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL



		Instructions for syndication.php
		
		action	string(article|comment)		article
					If action=comment only switch type
					is available.
		
		show		int(1-100)
					Number of posts to show.
		
		id			int
					Article ID.
		
		cat		int
					category ID.
		
		date		int(4|6|8)
					yyyy
					yyyymm
					yyyymmdd
		
		type		string(rss|html)				rss
					If 'html' HTML list items will be outputted,
					anything else will output an RSS 2.0 feed.

	 **************************************************/

	// some important stuff
	require('inc/config.php');
	
	if(isset($conf_syndicate_act) && $conf_syndicate_act == 0) {
		header('HTTP/1.1 404 Not Found');
		exit;
	}
	
	require('inc/mysql.php');
	require('inc/lang.php');
	require('inc/func_bbcode.php');
	require('inc/func_bbcode_strip.php');
	require('inc/func_truncate.php');
	
	$pattern = array("\r\n[more]\r\n", "[more]\r\n", '[more]');
	$replace = array(null, null, null);
	
	// check 'action'
	if(array_key_exists('action', $_GET)) {
		$action = $_GET['action'];
	}
	else {
		$action = null;
	}

	// check 'type' (html|*rss*)
	if(array_key_exists('type', $_GET)) {
		$type = $_GET['type'];
	}
	else {
		$type = 'rss';
	}

	// check 'show'
	if(array_key_exists('show', $_GET) && intval($_GET['show']) > 0 || array_key_exists('show', $_GET) && intval($_GET['show']) > 100) {
		$show = intval($_GET['show']);
	}
	else {
		$show = intval($conf_syndicate_limit);
	}
	
	// check 'id'
	if(array_key_exists('id', $_GET) && intval($_GET['id']) > 0) {
		$id = intval($_GET['id']);
	}
	else {
		$id = null;
	}
	
	// check 'cat'
	if(array_key_exists('cat', $_GET) && intval($_GET['cat']) > 0) {
		$cat = intval($_GET['cat']);
	}
	else {
		$cat = null;
	}
	
	// check 'date'
	if(array_key_exists('date', $_GET) && is_numeric($_GET['date'])) {
		$date = $_GET['date'];
	}
	else {
		$date = null;
	}



	switch($action) {
		case 'comment':
			// database queries
			$query = 'SELECT c.id, c.blog_id, UNIX_TIMESTAMP(c.date_created) AS date_created, UNIX_TIMESTAMP(c.date_created) AS date_modified, c.username, c.email, d.topic, c.comment AS text FROM ' . $conf_mysql_prefix . 'comments AS c, ' . $conf_mysql_prefix . 'data AS d WHERE d.draft=\'0\' AND c.blog_id=d.id ORDER BY date_created DESC LIMIT ' . $show;
			break;
		default: // articles
			// database queries
			if($id > 0) {
				$query = 'SELECT id as blog_id, UNIX_TIMESTAMP(date_created) AS date_created, UNIX_TIMESTAMP(date_modified) AS date_modified, topic, text FROM ' . $conf_mysql_prefix . 'data WHERE draft=\'0\' AND id=\'' . $id . '\' LIMIT 1';
			}
			else if($cat > 0) {
				$query = 'SELECT id as blog_id, UNIX_TIMESTAMP(date_created) AS date_created, UNIX_TIMESTAMP(date_modified) AS date_modified, topic, text FROM ' . $conf_mysql_prefix . 'data WHERE draft=\'0\' AND category_id=\'' . $cat . '\' ORDER BY date_created DESC LIMIT ' . $show;
			}
			else if(strlen($date) == 4) {
				$year = $date;
				$query = 'SELECT id as blog_id, UNIX_TIMESTAMP(date_created) AS date_created, UNIX_TIMESTAMP(date_modified) AS date_modified, topic, text FROM ' . $conf_mysql_prefix . 'data WHERE draft=\'0\' AND SUBSTRING(date_created, 1, 4)=\'' . $date . '\' ORDER BY date_created DESC LIMIT ' . $show;
			}
			else if(strlen($date) == 6) {
				$year = substr($date, 0, 4);
				$month = substr($date, 4, 2);
				$query = 'SELECT id as blog_id, UNIX_TIMESTAMP(date_created) AS date_created, UNIX_TIMESTAMP(date_modified) AS date_modified, topic, text FROM ' . $conf_mysql_prefix . 'data WHERE draft=\'0\' AND SUBSTRING(date_created, 1, 4)=\'' . $year. '\' AND SUBSTRING(date_created, 6, 2)=\'' . $month . '\' ORDER BY date_created DESC LIMIT ' . $show;
			}
			else if(strlen($date) == 8) {
				$year = substr($date, 0, 4);
				$month = substr($date, 4, 2);
				$day = substr($date, 6, 2);
				$query = 'SELECT id as blog_id, UNIX_TIMESTAMP(date_created) AS date_created, UNIX_TIMESTAMP(date_modified) AS date_modified, topic, text FROM ' . $conf_mysql_prefix . 'data WHERE draft=\'0\' AND SUBSTRING(date_created, 1, 4)=\'' . $year. '\' AND SUBSTRING(date_created, 6, 2)=\'' . $month . '\' AND SUBSTRING(date_created, 9, 2)=\'' . $day . '\' ORDER BY date_created DESC LIMIT ' . $show;
			}
			else {
				$query = 'SELECT id as blog_id, UNIX_TIMESTAMP(date_created) AS date_created, UNIX_TIMESTAMP(date_modified) AS date_modified, topic, text FROM ' . $conf_mysql_prefix . 'data WHERE draft=\'0\' ORDER BY date_created DESC LIMIT ' . $show;
			}
			break;
	}

	// fetch data
	$q = mysql_query($query);
	$n = mysql_num_rows($q);

	$monkey = null;

	// action switch
	switch($monkey) {
		default:
			$r = mysql_fetch_assoc($q);
		
			if($type == 'html') {
				if($n > 0) {
					mysql_data_seek($q, 0);
					// Items
					if($action == 'comment') {
						while($r = mysql_fetch_assoc($q)) {
							if(strlen($r['text']) > 100) {
								$text = htmlspecialchars(sStripSlashes(substr($r['text'], 0, 97))) . '...';
							}
							else {
								$text = htmlspecialchars(sStripSlashes($r['text']));
							}
							echo "\t" . '<li><a href="' . sRewrite('article', 'id', $r['blog_id'], 'anchor', $r['id']) . '" title="' . $text . '">' . $text . '</a></li>' . "\n";
						}
					}
					else {
						while($r = mysql_fetch_assoc($q)) {
							$topic = htmlspecialchars(sStripSlashes($r['topic']));
							echo "\t" . '<li><a href="' . sRewrite('article', 'id', $r['blog_id']) . '" title="' . $topic . '">' . $topic . '</a></li>' . "\n";
						}
					}
				}
			}
			else {
				// check if there's new data in document
				if(function_exists('apache_request_headers')) {
					$headers = apache_request_headers();
				}
				else if(function_exists('getallheaders')) {
					$headers = getallheaders();
				}
				
				// Return a 304 to client if there's nothing new
				if(isset($headers['If-Modified-Since']) && $headers['If-Modified-Since'] == gmdate('D, d M Y H:i:s', $r['date_modified']) . ' GMT') {
					mysql_close();
					header('HTTP/1.1 304 Not Modified' . "\r\n");
					exit;
				}
			
				// headers
				header('Content-type: application/xml; charset=' . $charset . "\r\n");
				header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 3600) . ' GMT' . "\r\n");
				header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $r['date_modified']) . ' GMT' . "\r\n");
				header('ETag: ' . $r['date_modified'] . "\r\n");
				header('Cache-Control: max-age=3600' . "\r\n");
			
				// Channel
				
				if($action == 'comment') {
					$title = htmlspecialchars(sStripSlashes($conf_page_title)) . ' comments';
				}
				else {
					$title = htmlspecialchars(sStripSlashes($conf_page_title));
				}
				
				echo '<?xml version="1.0" encoding="' . $charset . '"?>' . "\r\n";
				echo '<rss version="2.0">' . "\r\n";
				echo '<channel>' . "\r\n";
				echo "\t" . '<title><![CDATA[' . $title . ']]></title>' . "\r\n";
				echo "\t" . '<link>' . $conf_web_root . '</link>' . "\r\n";
				echo "\t" . '<description>RSS feed of ' . $conf_page_title . '</description>' . "\r\n";
				echo "\t" . '<language>en-us</language>' . "\r\n";
				echo "\t" . '<copyright><![CDATA[&copy; ' . $conf_admin_username . ' @ ' . $conf_web_root . ']]></copyright>' . "\r\n";
				echo "\t" . '<generator>sBLOG ' . $conf_current_version . ' (Build ' . $conf_current_build . ')</generator>' . "\r\n";
				echo "\t" . '<pubDate>' . gmdate('D, d M Y H:i:s', $r['date_created']) . ' GMT</pubDate>' . "\r\n";
				echo "\t" . '<lastBuildDate>' . gmdate('D, d M Y H:i:s', $r['date_modified']) . ' GMT</lastBuildDate>' . "\r\n";

				if($n > 0) {
					mysql_data_seek($q, 0);
					// Items
					while($r = mysql_fetch_assoc($q)) {
						if($action == 'comment') {
							$text = 'Comment from: ' . htmlspecialchars(sStripSlashes($r['username']));
							if(strlen($r['email']) > 0) {
								$text .= ' &lt;' . htmlspecialchars(sStripSlashes($r['email'])) . '&gt;';
							}
							$text .= '<br /><br />' . bbcode(str_replace($pattern, $replace, $r['text']));
						}
						else {
							$text = bbcode(str_replace($pattern, $replace, $r['text']));
						}
						echo "\t" . '<item>' . "\r\n";
						echo "\t\t" . '<title><![CDATA[' . htmlspecialchars(substr(sStripSlashes($r['topic']), 0, 40)) . ']]></title>' . "\r\n";	// max 40 chars
						if($action == 'comment') {
							echo "\t\t" . '<link>' . sRewrite('article', 'id', $r['blog_id'], 'anchor', $r['id']) . '</link>' . "\r\n";
						}
						else {
							echo "\t\t" . '<link>' . sRewrite('article', 'id', $r['blog_id']) . '</link>' . "\r\n";
						}
						echo "\t\t" . '<description><![CDATA[' . $text . ']]></description>' . "\r\n";
						echo "\t\t" . '<pubDate>' . gmdate('D, d M Y H:i:s', $r['date_created']) . ' GMT</pubDate>' . "\r\n";
						echo "\t\t" . '<comments>' . sRewrite('comments', 'id', $r['blog_id']) . '</comments>' . "\r\n";
						//echo "\t\t" . '<author><![CDATA[' . $conf_admin_username . ' <' . $conf_admin_email . '>]]></author>' . "\r\n";
						if($action == 'comment') {
							echo "\t\t" . '<guid isPermaLink="true">' . sRewrite('article', 'id', $r['blog_id'], 'anchor', $r['id']) . '</guid>' . "\r\n";
						}
						else {
							echo "\t\t" . '<guid isPermaLink="true">' . sRewrite('article', 'id', $r['blog_id']) . '</guid>' . "\r\n";
						}
						echo "\t" . '</item>' . "\r\n";
					}
				}

				echo '</channel>' . "\r\n";
				echo '</rss>';
			}
			break;
		}

	// close database connection	
	mysql_close();

?>